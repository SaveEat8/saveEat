import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import * as xlsx from 'xlsx';
declare var $: any
@Component({
  selector: 'app-restaurant-transaction',
  templateUrl: './restaurant-transaction.component.html',
  styleUrls: ['./restaurant-transaction.component.css']
})
export class RestaurantTransactionComponent implements OnInit {

  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  @ViewChild('epltable1', { static: false }) epltable1: ElementRef;


  p: any = 1;
  p1: any = 1;
  srNo: any;
  total: any = Number;
  pages: any;
  itemPerPage: any = 50;
  restaurantsLists: any = []
  restaurantsCount: any
  brandLists: any = []
  brandsCount: any
  brandId: any
  getBrandId: any
  brandsDetails: any
  restaurantId: any
  search: any = FormGroup;
  searchBrand: any;
  calanderSearch: any = FormGroup;
  selectedItems: any = []
  calanderSearchStore: any = FormGroup;

  formvalidation: any = { submitted: false }
  selectedValue: any = 'Today'
  selectedValue1: any = 'Today'

  profilePic: any = localStorage.getItem("profilePic")

  restrauntId: any
  restaurantData: any = []

  searchText:any 


  onTodayStatus: any = true
  searchStatus: any = false
  calanderStatus: any = false

  onTodayStatus1: any = true
  searchStatus1: any = false
  calanderStatus1: any = false

  restaurantsLists1:any

  viewCheck:any = false
  editCheck:any = false

  adminType= localStorage.getItem('userType');


  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {

    this.searchBrand = this.formBuilder.group({
      search: ['', [Validators.required]]
    });

    this.search = this.formBuilder.group({
      search: ['', [Validators.required]]
    });

    this.calanderSearch = this.formBuilder.group({
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]]
    });

    this.calanderSearchStore = this.formBuilder.group({
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]]
    });
  }


  ngOnInit(): void {
    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')

    console.log("this.viewCheck==>",this.viewCheck)
    console.log("this.editCheck==>",this.editCheck)
    localStorage.removeItem("restorentId");
    localStorage.removeItem("storeId");
    localStorage.removeItem("transectionStoreId");

    // localStorage.removeItem("restorentId");
    // localStorage.removeItem("storeId");

    localStorage.removeItem("coustmerId");

    this.onToday('Today')

  }


  onRestaurantsLists() {

    let apiData = {
      pageNumber: this.p

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/storeTransectionList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.restaurantsLists = success.Data
        this.restaurantsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRestaurantsListsPagination(event: any) {
    this.p = event
    // let apiData = {
    //   pageNumber:this.p

    // }
    let apiData

    if (this.onTodayStatus == true) {
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "timeframe": this.selectedValue,
      }
    }

    if (this.searchStatus == true) {
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
      }
    }

    if (this.calanderStatus == true) {

      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }


    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/storeTransectionList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.restaurantsLists = success.Data
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch() {
    this.p = 1
    this.formvalidation.submitted = true
    this.searchStatus = true
    if (this.search.invalid) {
      this.onToday(this.selectedValue)
      // this.service.err("Please enter cuisin name!")
      return
    }

    // this.restaurantsLists = success.Data
    // console.log("this.restaurantsLists==>", this.restaurantsLists)
    // this.restaurantsCount = success.TotalRestorent


    // var set = [{"color":"blue"},{"color":"green"},{"color":"red"},{"color":"green"}];
    // businessName: "McDonald Gaurcity"
// createdAt: "2021-08-19T07:57:12.838Z"
// empNumber
let restaurantsLists12 = []

console.log("results==>",this.restaurantsLists)



this.restaurantsLists1 = this.restaurantsLists

restaurantsLists12 = this.restaurantsLists.filter((val:any) => {
  return  val['businessName'] == this.search.value.search.toUpperCase()
})

  //  var results = this.restaurantsLists.filter((entry:any) =>  entry.businessName ==  this.search.value.search);

   console.log("results==>",restaurantsLists12)

  //  this.restaurantsLists = results

   this.restaurantsCount = this.restaurantsLists.length


    // this.onTodayStatus = false
    // this.searchStatus = true
    // this.calanderStatus = false

    // let apiData = {
    //   pageNumber: this.p,
    //   limit: this.itemPerPage,
    //   "search": this.search.value.search,
    // }

    let apiData = {
      
    }

    // this.onTodayStatus = false
    // this.searchStatus = true
    // this.calanderStatus = false 

    // if(this.calanderStatus == true){
    //   apiData = {
    //     pageNumber: this.p,
    //     limit: this.itemPerPage,
    //     "search": this.search.value.search,
    //     "startDate": new Date(this.calanderSearch.value.startDate),
    //     "endDate": new Date(this.calanderSearch.value.endDate),
    //   }

    // }

    // if(this.onTodayStatus ==true){
    //   apiData = {
    //     pageNumber: this.p,
    //     limit: this.itemPerPage,
    //     "search": this.search.value.search,
    //     "timeframe": this.selectedValue,

    //   }
    // }

    // this.service.showSpinner()
    // this.service.postApi('/api/v1/adminUser/storeTransectionList', apiData, 0).subscribe((success) => {
    //   console.log("success==>", success)

    //   if (success.response_code == 200) {
    //     this.service.hideSpinner()
    //     console.log("success Check==>", success)
    //     this.restaurantsLists = success.Data
    //     console.log("this.restaurantsLists==>", this.restaurantsLists)
    //     this.restaurantsCount = success.TotalRestorent
    //     // this.service.succ(success.message)

    //   }
    //   else {
    //     this.service.hideSpinner()
    //     this.service.err(success.message)
    //   }
    // }, error => {
    //   this.service.hideSpinner()
    // })
  }

  exportToExcel() {
    const ws: xlsx.WorkSheet =
      xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'restaurantTransectionList.xlsx');

  //   let apiData 

  //   if(this.onTodayStatus == true){
  //     apiData = {
  //      "timeframe": this.selectedValue,
  //    }
  //  }

  // //  if(this.calanderStatus == true){
  // //   apiData = {
  // //     "startDate": new Date(this.calanderSearch.value.startDate),
  // //     "endDate": new Date(this.calanderSearch.value.endDate),
  // //   }
  // // }

  // if(this.searchStatus == true){
  //   apiData = {
  //     "search": this.search.value.search,
  //   }
  // }
  // console.log("apiData==>",apiData)
  // console.log("this.searchStatus==>",this.searchStatus)

  //   this.service.showSpinner()
  //   this.service.postApi('/api/v1/adminUser/downloadStoreTransectionList', apiData, 1).subscribe((success) => {
  //     console.log("success==>",success)

  //     if (success.response_code == 200) {
  //       this.service.hideSpinner()
  //       console.log("success==>",success)
  //       window.open(success.Data, '_blank');
  //     }
  //     else {
  //       this.service.hideSpinner()
  //       this.service.err(success.message)
  //     }
  //   }, error => {
  //     this.service.hideSpinner()
  //   })
  }

  onCalenderSearch() {
    this.p = 1
    this.formvalidation.submitted = true
    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus = false
    // this.searchStatus = false
    this.calanderStatus = true

    //   let startDate =  new Date(this.calanderSearch.value.startDate);
    //   let endDate = new Date(this.calanderSearch.value.endDate);

    //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
    //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


    //   let startDates = new Date(updatedStartDate)
    //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/storeTransectionList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.restaurantsLists = success.Data
        this.restaurantsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(value: any) {
    this.selectedValue = value
    this.p = 1

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "timeframe": value,
    }

    this.onTodayStatus = true
    this.searchStatus = true
    this.calanderStatus = false

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/storeTransectionList', apiData, 0).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success Check==>", success)
        this.restaurantsLists = success.Data
        console.log("this.restaurantsLists==>", this.restaurantsLists)
        this.restaurantsCount = success.TotalRestorent
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetRestrauntId(id: any) {
    this.restrauntId = id
    let apiData = {
      orderId: id
    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/storeTransectionList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)
      if (success.response_code == 200) {
        console.log("success==>", success)
        this.restaurantData = success.Data[0]
        console.log("this.restaurantData==>", this.restaurantData)
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  exportToExcel1() {
    const ws: xlsx.WorkSheet =
      xlsx.utils.table_to_sheet(this.epltable1.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'storeTransactionsList.xlsx');
  }

  onStoreId(id: any) {
    this.brandId = id
    localStorage.setItem('transectionStoreId', this.brandId)
    this.onStoreDetails('Today')
  }


  onStoreDetails(value: any) {

    if(this.viewCheck == 'false'){
      $("#credit").modal("hide");
      return this.service.err("User Not allowed to perform this action")
    }


    this.selectedValue1 = value
    this.p1 = 1

    let apiData = {
      storeId: localStorage.getItem('transectionStoreId'),
      pageNumber: this.p1,
      limit: this.itemPerPage,
      "timeframe": value,
      // storeId: '611e0ed8e8625c51160a8a4e'
    }

    this.onTodayStatus1 = true
    this.searchStatus1 = true
    this.calanderStatus1 = false

    console.log("data===>", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/particularStoreTransection', apiData, 0).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success Check==>", success)
        this.brandLists = success.Data
        this.brandsCount = success.Total
        this.brandsDetails = success.StoreData[0]
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onOrderDetail(id: any) {
    $("#credit").modal("hide");

    this.route.navigate(['/refund-already', id])

  }

  onRestaurntDetail(id: any) {
    $("#credit").modal("hide");

    this.route.navigate(['/restaurants-personal-information', id])
  }

  onCalenderStoreSearch() {
    this.p1 = 1
    this.formvalidation.submitted = true
    if (this.calanderSearchStore.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus1 = false
    // this.searchStatus1 = false
    this.calanderStatus1 = true

    //   let startDate =  new Date(this.calanderSearch.value.startDate);
    //   let endDate = new Date(this.calanderSearch.value.endDate);

    //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
    //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


    //   let startDates = new Date(updatedStartDate)
    //   let endDates = new Date()



    let apiData = {
      storeId: localStorage.getItem('transectionStoreId'),
      pageNumber: this.p1,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearchStore.value.startDate),
      "endDate": new Date(this.calanderSearchStore.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/particularStoreTransection', apiData, 0).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success Check==>", success)
        this.brandLists = success.Data
        this.brandsCount = success.Total
        this.brandsDetails = success.StoreData[0]
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onStoreListsPagination(event: any) {
    this.p1 = event
    // let apiData = {
    //   pageNumber:this.p

    // }
    let apiData

    if (this.onTodayStatus == true) {
      apiData = {
        storeId: localStorage.getItem('transectionStoreId'),
        pageNumber: this.p1,
        limit: this.itemPerPage,
        "timeframe": this.selectedValue1,
      }
    }

    if (this.searchStatus == true) {
      apiData = {
        storeId: localStorage.getItem('transectionStoreId'),
        pageNumber: this.p1,
        limit: this.itemPerPage,
        "search": this.search.value.search,
      }
    }

    if (this.calanderStatus == true) {

      apiData = {
        storeId: localStorage.getItem('transectionStoreId'),
        pageNumber: this.p1,
        limit: this.itemPerPage,
        "startDate": new Date(this.calanderSearchStore.value.startDate),
        "endDate": new Date(this.calanderSearchStore.value.endDate),
      }

    }


    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/particularStoreTransection', apiData, 0).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success Check==>", success)
        this.brandLists = success.Data
        this.brandsCount = success.Total
        this.brandsDetails = success.StoreData[0]
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onBrandSearch() {
    this.p1 = 1
    this.formvalidation.submitted = true
    if (this.searchBrand.invalid) {
      this.onStoreDetails(this.selectedValue)
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus1 = false
    this.searchStatus1 = true
    this.calanderStatus1 = false

    let apiData = {
      storeId: localStorage.getItem('transectionStoreId'),
      pageNumber: this.p1,
      limit: this.itemPerPage,
      "search": this.searchBrand.value.search,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/particularStoreTransection', apiData, 0).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success Check==>", success)
        this.brandLists = success.Data
        this.brandsCount = success.Total
        this.brandsDetails = success.StoreData[0]
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }



  onGetRestaurentId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/restaurants-personal-information',id])
  }

  onGetOrderDetailId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/refund-already',id])
  }

  onGetCustomerDetailId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/customers-details',id])
  }

  onGetStoreDetailId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/store-personal-info',id])
  }



}
