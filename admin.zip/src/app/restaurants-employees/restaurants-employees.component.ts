import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurants-employees',
  templateUrl: './restaurants-employees.component.html',
  styleUrls: ['./restaurants-employees.component.css']
})
export class RestaurantsEmployeesComponent implements OnInit {
  profilePic:any=localStorage.getItem("profilePic")
  fetchId:any
  constructor() { }

  ngOnInit(): void {
    this.onFetchId()
  }

  onFetchId(){
    this.fetchId = localStorage.getItem("restorentId")
  }

}
