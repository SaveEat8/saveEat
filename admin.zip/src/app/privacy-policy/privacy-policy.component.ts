import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service'
import { Router } from '@angular/router';
// import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
  selector: 'app-privacy-policy',
  templateUrl: './privacy-policy.component.html',
  styleUrls: ['./privacy-policy.component.css']
})
export class PrivacyPolicyComponent implements OnInit {
  public Editor: any = ClassicEditor;

  contentData: any
  termsData: any
  faqs: any
  aboutUsForm: FormGroup
  termsForm: FormGroup
  faqForm: FormGroup
  privacyPolicyData:any

  editCheck:any = false


  constructor(public appService: AppService,
    private formBuilder: FormBuilder,
    private router: Router) {
    this.aboutUsForm = this.formBuilder.group({
      data: ['']
    });
  }

  ngOnInit(): void {
    this.editCheck = localStorage.getItem('Edit')

    this.onGetData()
  }

  onGetData() {

    let apiData = {
      'contentId': "61123bddcec20e27cc1670d1",
    }



    console.log("data", apiData)
    this.appService.showSpinner()
    this.appService.postApi('/api/v1/adminStatic/getStaticContentByType', apiData, 1).subscribe((success) => {
      console.log("success==>", success)
      if (success.status == 200) {
        this.appService.hideSpinner()

        this.privacyPolicyData = success.data.description

      }
      else {
        this.appService.hideSpinner()
        this.appService.err(success.message)
      }
    }, error => {
      this.appService.hideSpinner()
    })
  }

  onSubmit() {
    if(this.editCheck == 'false'){
      return this.appService.err("User Not allowed to perform this action")
    }
    console.log("data===>", this.aboutUsForm.value.data)

    let apiData = {
      'contentId': "61123bddcec20e27cc1670d1",
      'description':this.aboutUsForm.value.data
    }



    console.log("data", apiData)
    this.appService.showSpinner()
    this.appService.postApi('/api/v1/adminStatic/updateContent', apiData, 1).subscribe((success) => {
      console.log("success==>", success)
      if (success.status == 200) {
        this.appService.hideSpinner()
        this.appService.succ("Content Updated")

      }
      else {
        this.appService.hideSpinner()
        this.appService.err(success.message)
      }
    }, error => {
      this.appService.hideSpinner()
    })
  }

}
