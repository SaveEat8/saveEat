import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';

@Component({
  selector: 'app-restaurants-personal-information',
  templateUrl: './restaurants-personal-information.component.html',
  styleUrls: ['./restaurants-personal-information.component.css']
})
export class RestaurantsPersonalInformationComponent implements OnInit {

  profilePic:any=localStorage.getItem("profilePic")
  id:any;
  restaurantData:any
  openingTime:any
  holidays:any
  favCount:any
  tax:any 
  fee:any 


  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute
    ) { }

  ngOnInit(): void {
    if(localStorage.getItem("restorentId")){
      this.id = localStorage.getItem("restorentId")
      this.onRestaurantDetail()
      this.onGetAdmin()
    }else{
      this.getId()
      this.onGetAdmin()
    }
  }

  getId() {
    this.activatedRoute.params.subscribe((paramsId) => {
      this.id = paramsId.id
      console.log('Check',this.id)
      localStorage.setItem("restorentId",this.id)
    })

    this.onRestaurantDetail()

  }

  onRestaurantDetail(){
    let apiData = {
      restaurntId:this.id
    }
    console.log("data",apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/particularRestaurnt', apiData, 1).subscribe((success) => {
      console.log("success==>",success)
      if (success.status == 200) {
        console.log("success==>",success)
        this.restaurantData = success.Data
        this.openingTime = success.Openings
        this.holidays = success.Holidays
        this.favCount=  success.FavCount
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetAdmin(){



    let apireq = {

      adminId: localStorage.getItem("superId")
    }
    this.service.postApi('/api/v1/admin/getAdminDetailss', apireq, 1).subscribe(success => {
      console.log("success==>",success)
      if (success.status == 200) {
       this.tax = success.data.tax
       this.fee = success.data.fee
      }
      else {
        this.service.err(success.message);
      }
    }, error => {
      console.log("Something went wrong")
    })
  }

}
