import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';


@Pipe({ name: 'convertTime' })
export class Time24to12Format implements PipeTransform {

    transform(value: number, args?: any): any {
        return this.convertTime(value);
    }
    convertTime(point: number): String {
        return moment(`${point}`, "hh:mm").format('LT')
    }


}