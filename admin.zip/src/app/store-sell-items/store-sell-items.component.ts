import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../app.service';

@Component({
  selector: 'app-store-sell-items',
  templateUrl: './store-sell-items.component.html',
  styleUrls: ['./store-sell-items.component.css']
})
export class StoreSellItemsComponent implements OnInit {
  profilePic:any=localStorage.getItem("profilePic")
  fetchId:any

  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 10;
  sellItemList:any = []
  sellItemCount:any
  menuId:any
  getBrandId:any
  restaurantId:any

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.onFetchId()
    this.onMenuLists() 
   }

  onFetchId(){
    this.fetchId = localStorage.getItem("storeId")
  }


  onMenuLists(){

    let apiData = {
      brandId:localStorage.getItem("storeId"),
      pageNumber:this.p

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/sellItemsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.sellItemList = success.Data
        this.sellItemCount = success.TotalCount
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }
  
  onMenuListsPagination(event:any){
    this.p = event
    let apiData = {
      brandId:localStorage.getItem("storeId"),
      pageNumber:this.p

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/sellItemsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.sellItemList = success.Data
        this.sellItemCount = success.TotalCount
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


}
