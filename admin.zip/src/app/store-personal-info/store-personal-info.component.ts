import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';

@Component({
  selector: 'app-store-personal-info',
  templateUrl: './store-personal-info.component.html',
  styleUrls: ['./store-personal-info.component.css']
})
export class StorePersonalInfoComponent implements OnInit {
  id:any;
  restaurantData:any
  profilePic:any=localStorage.getItem("profilePic")
  openingTime:any
  holidays:any
  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    if(localStorage.getItem("storeId")){
      this.id = localStorage.getItem("storeId")
      this.onRestaurantDetail()
    }else{
      this.getId()
    }

    // this.getId()
  }

  getId() {
    this.activatedRoute.params.subscribe((paramsId) => {
      this.id = paramsId.id
      console.log('Check',this.id)
      localStorage.setItem("storeId",this.id)
    })

    this.onRestaurantDetail()

  }

  onRestaurantDetail(){
    let apiData = {
      restaurntId:this.id
    }
    console.log("data",apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/particularRestaurnt', apiData, 1).subscribe((success) => {
      console.log("success==>",success)
      if (success.status == 200) {
        console.log("success==>",success)
        this.restaurantData = success.Data
        this.openingTime = success.Openings
        this.holidays = success.Holidays
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

}
