import { Component, OnInit } from '@angular/core';
declare function sidebar(): any;
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  accessData: any
  accessData1: any

  checkingRole: any

  adminType: any

  Customers: any = false
  Restaurants: any = false
  Orders: any = false
  Finance: any = false
  Rewards: any = false
  Credits: any = false
  Users: any = false
  Cuisines: any = false
  Static: any = false



  constructor() { }

  ngOnInit(): void {
    localStorage.setItem('View', 'false')
    localStorage.setItem('Edit', 'false')
    localStorage.setItem('Delete', 'false')
    localStorage.setItem('Add', 'false')
    localStorage.setItem('Block', 'false')

    this.onGetAcessData()

    sidebar()
  }

  onGetAcessData() {
    this.adminType = localStorage.getItem('userType');
    // this.adminType= "Admin"

    if (this.adminType == "SubAdmin") {
      this.accessData1 = localStorage.getItem('Role');

      console.log('retrievedObject: ', JSON.parse(this.accessData1))


      this.accessData = JSON.parse(this.accessData1)




      console.log('retrievedObject: ', this.accessData)
    }



    if (this.adminType == 'SubAdmin') {
      console.log("subadmin==>")
      for (let i = 0; i < this.accessData.module.length; i++) {

        if (this.accessData.module[i].title == 'Customers') {
          console.log("this.Customers==>")
          this.Customers = true
        }

        if (this.accessData.module[i].title == 'Restaurants') {
          this.Restaurants = true

        }

        if (this.accessData.module[i].title == 'Orders') {
          this.Orders = true

        }

        if (this.accessData.module[i].title == 'Finance') {
          this.Finance = true

        }

        if (this.accessData.module[i].title == 'Rewards') {
          this.Rewards = true

        }

        if (this.accessData.module[i].title == 'Credits') {
          this.Credits = true

        }

        if (this.accessData.module[i].title == 'Users') {
          this.Users = true

        }

        if (this.accessData.module[i].title == 'Cuisines') {
          this.Cuisines = true

        }

        if (this.accessData.module[i].title == 'Static') {
          this.Static = true

        }

      }
      console.log("subadmin==>")

      for (let j = 0; j < this.accessData.actions.length; j++) {
        if (this.accessData.actions[j] == 'View') {
          localStorage.setItem('View', 'true');
         
        }

        if (this.accessData.actions[j] == 'Edit') {
          localStorage.setItem('Edit', 'true');
        
        }

        if (this.accessData.actions[j] == 'Delete') {
          localStorage.setItem('Delete', 'true');
        
        }

        if (this.accessData.actions[j] == 'Add') {
          localStorage.setItem('Add', 'true');
        }

        if (this.accessData.actions[j] == 'Block') {
          localStorage.setItem('Block', 'true');

        }


      }

    }

    if (this.adminType == 'Admin') {
      console.log("this.adminType Admin =======>", this.adminType)
      this.Customers = true
      this.Restaurants = true
      this.Orders = true
      this.Finance = true
      this.Rewards = true
      this.Credits = true
      this.Users = true
      this.Cuisines = true
      this.Static = true
      console.log("this.adminType end =======>", this.adminType)

      localStorage.setItem('View', 'true');
      localStorage.setItem('Edit', 'true');
      localStorage.setItem('Delete', 'true');
      localStorage.setItem('Add', 'true');
      localStorage.setItem('Block', 'true');


      // 'View' ,
      // 'Edit' ,
      // 'Delete' ,
      // 'Add' ,
      // 'Block' ,
    }


    console.log("this.adminType==>", this.adminType)


  }



}
