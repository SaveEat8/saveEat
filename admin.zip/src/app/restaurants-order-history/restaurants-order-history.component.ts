import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import * as xlsx from 'xlsx';
declare var $:any
import {
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexChart,
  ApexFill
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  fill: ApexFill;
  labels: string[];
  plotOptions: ApexPlotOptions;
};


@Component({
  selector: 'app-restaurants-order-history',
  templateUrl: './restaurants-order-history.component.html',
  styleUrls: ['./restaurants-order-history.component.css']
})
export class RestaurantsOrderHistoryComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 10;
  restaurantsLists:any = []
  restaurantsCount:any
  brandLists:any = []
  brandsCount:any
  brandId:any
  getBrandId:any
  restaurantId:any
  search:any = FormGroup;
  calanderSearch:any = FormGroup;
  calanderSearch1:any = FormGroup;

  formvalidation: any = { submitted: false }
  selectedValue :any = 'Today'

  selectedValue1 :any = 'Today'

  

  onTodayStatus:any = true
  searchStatus:any = false
  calanderStatus:any = false 

  chartStatus: any = false


  chartData: any = 40
  chartData1: any = 40
  chartData2: any = 40
  chartData3: any = 0
  chartData4: any = 0
  chartData5: any = 0
  chartData6: any = 0
  chartData7: any = 0

  totalUsers: any = 0
  totalRestaurnt: any = 0
  totalOrder: any = 0
  totalItem:any = 0

  onTodayStatus1:any = true
  searchStatus1:any = false
  calanderStatus1:any = false 

  onTodayStatus2: any = true
  searchStatus2: any = false
  calanderStatus2: any = false

  onTodayStatus5: any = true
  searchStatus5: any = false
  calanderStatus5: any = false

  amount:any
  credit:any

 // @ViewChild("chart") chart: ChartComponent | any;
 public chartOptions: Partial<ChartOptions> | any;
 public chartOptions1: Partial<ChartOptions> | any;
 public chartOptions2: Partial<ChartOptions> | any;
 public chartOptions3: Partial<ChartOptions> | any;
 public chartOptions4: Partial<ChartOptions> | any;
 public chartOptions5: Partial<ChartOptions> | any;
 public chartOptions6: Partial<ChartOptions> | any;
 public chartOptions7: Partial<ChartOptions> | any;

 profilePic:any=localStorage.getItem("profilePic")
 fetchId:any
 constructor( private route: Router,
  private service: AppService,
  private activatedRoute: ActivatedRoute,
  private formBuilder: FormBuilder) {
   this.chartOptions = {
     series: [this.chartData],
     chart: {
       height: 175,
       type: "radialBar"
     },
     fill: {
       opacity: 1,
       colors: ['#85D8D9']
     },
     plotOptions: {
       radialBar: {
         hollow: {
           size: "70%"
         }
       }
     },
  
     // labels: ["Financial"]
   };

   this.chartOptions1 = {
    series: [this.chartData1],
    chart: {
      height: 175,
      type: "radialBar"
    },
    fill: {
      opacity: 1,
      colors: ['#85D8D9']
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: "70%"
        }
      }
    },
 
    // labels: ["Financial"]
  };

  this.chartOptions2 = {
    series: [this.chartData2],
    chart: {
      height: 120,
      type: "radialBar"
    },
    fill: {
      opacity: 1,
      colors: ['#85D8D9']
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: "50%"
        }
      }
    },

    // labels: ["Financial"]
  };

  this.chartOptions3 = {
    series: [this.chartData3],
    chart: {
      height: 120,
      type: "radialBar"
    },
    fill: {
      opacity: 1,
      colors: ['#85D8D9']
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: "50%"
        }
      }
    },

    // labels: ["Financial"]
  };

  this.chartOptions4 = {
    series: [this.chartData4],
    chart: {
      height: 120,
      type: "radialBar"
    },
    fill: {
      opacity: 1,
      colors: ['#85D8D9']
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: "50%"
        }
      }
    },

    // labels: ["Financial"]
  };

  this.chartOptions5 = {
    series: [this.chartData5],
    chart: {
      height: 120,
      type: "radialBar"
    },
    fill: {
      opacity: 1,
      colors: ['#85D8D9']
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: "50%"
        }
      }
    },

    // labels: ["Financial"]
  };

  this.chartOptions6 = {
    series: [this.chartData6],
    chart: {
      height: 120,
      type: "radialBar"
    },
    fill: {
      opacity: 1,
      colors: ['#85D8D9']
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: "50%"
        }
      }
    },

    // labels: ["Financial"]
  };

  this.chartOptions7 = {
    series: [this.chartData7],
    chart: {
      height: 120,
      type: "radialBar"
    },
    fill: {
      opacity: 1,
      colors: ['#85D8D9']
    },
    plotOptions: {
      radialBar: {
        hollow: {
          size: "50%"
        }
      }
    },

    // labels: ["Financial"]
  };




   this.search = this.formBuilder.group({
    search: ['', [Validators.required]]
  });

  this.calanderSearch = this.formBuilder.group({
    startDate: ['', [Validators.required]],
    endDate: ['', [Validators.required]]
  });

  this.calanderSearch1 = this.formBuilder.group({
    startDate: ['', [Validators.required]],
    endDate: ['', [Validators.required]]
  });

   
  }

 ngOnInit(): void {
    // localStorage.removeItem("restorentId");
    // localStorage.removeItem("storeId");
    localStorage.removeItem("coustmerId");
   this.onFetchId()
 }

 onFetchId(){
  this.fetchId = localStorage.getItem("restorentId")

  this.onToday('Today')
  this.onToday1('Today')
}




onRestaurantsLists(){

  let apiData = {
    pageNumber:this.p,
    storeId:this.fetchId

  }
  console.log("data",apiData)
  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntOrderListAdmin', apiData, 1).subscribe((success) => {
    console.log("success==>",success)

    if (success.response_code == 200) {
              this.service.hideSpinner()
      console.log("success==>",success)
      this.restaurantsLists = success.Data
      this.restaurantsCount = success.TotalCount
      this.amount=success.Amount
      this.credit=success.Credit
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}

onRestaurantsListsPagination(event:any){
  this.p = event
  // let apiData = {
  //   pageNumber:this.p

  // }
  let apiData 

  if(this.onTodayStatus == true){
    apiData = {
     pageNumber:this.p,
     storeId:this.fetchId,
     limit: this.itemPerPage,
     "timeframe": this.selectedValue,
   }
 }

 if(this.searchStatus == true){
   apiData = {
     pageNumber:this.p,
     storeId:this.fetchId,
     limit: this.itemPerPage,
     "search": this.search.value.search,
   }
 }

 if(this.calanderStatus == true){

   apiData = {
     pageNumber:this.p,
     storeId:this.fetchId,
     limit: this.itemPerPage,
     "startDate": new Date(this.calanderSearch.value.startDate),
     "endDate": new Date(this.calanderSearch.value.endDate),
   }

 }


  console.log("data",apiData)
  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntOrderListAdmin', apiData, 1).subscribe((success) => {
    console.log("success==>",success)

    if (success.response_code == 200) {
       this.service.hideSpinner()
      console.log("success==>",success)
      this.restaurantsLists = success.Data
      this.amount=success.Amount
      this.credit=success.Credit
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}

onSearch(){
  this.p = 1
  this.formvalidation.submitted = true
  if (this.search.invalid) {
    this.onToday(this.selectedValue)
    // this.service.err("Please enter cuisin name!")
    return
  }

  this.onTodayStatus = false
  this.searchStatus = true
  this.calanderStatus = false 

  let apiData = {
    pageNumber: this.p,
    storeId:this.fetchId,
    limit: this.itemPerPage,
    "search": this.search.value.search,
  }

  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntOrderListAdmin', apiData, 1).subscribe((success) => {
    console.log("success==>",success)

    if (success.response_code == 200) {
              this.service.hideSpinner()
      console.log("success==>",success)
      this.restaurantsLists = success.Data
      this.restaurantsCount = success.TotalCount
      this.amount=success.Amount
      this.credit=success.Credit
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}

exportToExcel() {
  const ws: xlsx.WorkSheet =
  xlsx.utils.table_to_sheet(this.epltable.nativeElement);
  const wb: xlsx.WorkBook = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
  xlsx.writeFile(wb, 'orderList.xlsx');
}


onCalenderSearch(){
  this.p = 1
  this.formvalidation.submitted = true
  if (this.calanderSearch.invalid) {
    // this.onCuisinesLists()
    // this.service.err("Please enter cuisin name!")
    return
  }

  this.onTodayStatus = false
  this.searchStatus = false
  this.calanderStatus = true 

//   let startDate =  new Date(this.calanderSearch.value.startDate);
//   let endDate = new Date(this.calanderSearch.value.endDate);

//  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
//  let updatedendDate = endDate.setDate(startDate.getDate()+1)


//   let startDates = new Date(updatedStartDate)
//   let endDates = new Date()



  let apiData = {
    pageNumber: this.p,
    storeId:this.fetchId,
    limit: this.itemPerPage,
    "startDate": new Date(this.calanderSearch.value.startDate),
    "endDate": new Date(this.calanderSearch.value.endDate),
  }

  console.log("data", apiData)
  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntOrderListAdmin', apiData, 1).subscribe((success) => {
    console.log("success==>",success)

    if (success.response_code == 200) {
              this.service.hideSpinner()
      console.log("success==>",success)
      this.restaurantsLists = success.Data
      this.restaurantsCount = success.TotalCount
      this.amount=success.Amount
      this.credit=success.Credit
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}

onToday(value:any){
  this.selectedValue = value
  this.p = 1

  let apiData = {
    pageNumber:this.p,
    storeId:this.fetchId,
    limit: this.itemPerPage,
    "timeframe": value,
  }

  this.onTodayStatus = true
  this.searchStatus = false
  this.calanderStatus = false 

  console.log("data",apiData)
  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntOrderListAdmin', apiData, 1).subscribe((success) => {
    console.log("success==>",success)

    if (success.response_code == 200) {
              this.service.hideSpinner()
      console.log("success==>",success)
      this.restaurantsLists = success.Data
      this.restaurantsCount = success.TotalCount
      this.amount=success.Amount
      this.credit=success.Credit
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}


// ============================== dashboard ========================================//

onToday1(value: any) {
  this.selectedValue1 = value
  this.onOrderLists(value)
  this.onItemsLists(value)
}

onorderStatus(event: any) {
  let apiData = {}

  // this.onTodayStatus = true
  // this.searchStatus = false
  // this.calanderStatus = false
  if(this.onTodayStatus1 == true){
    apiData = {
      storeId:this.fetchId,
      "timeframe": this.selectedValue1,
      "status": event.target.value
    } 
  }

  if(this.calanderStatus1 == true){
    apiData = {
      storeId:this.fetchId,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
      "status": event.target.value
    }
  }
  console.log("data", apiData)
  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntOrderDashboard', apiData, 1).subscribe((success) => {
    console.log("success==>", success)

    if (success.response_code == 200) {
      this.service.hideSpinner()
      console.log("success==>", success)

      this.totalOrder = success.Data

      let totalpercentage = success.TotalPercentage

      this.chartData2 = totalpercentage.toFixed(2)

      // this.chartData1 = success.TotalPercentage

      this.chartOptions2 = {
        series: [this.chartData2],
        chart: {
          height: 120,
          type: "radialBar"
        },
        fill: {
          opacity: 1,
          colors: ['#85D8D9']
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "50%"
            }
          }
        },

        // labels: ["Financial"]
      };
      // this.usersLists = success.data.docs
      // this.usersCount = success.data.total
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}



onItemStatus(event: any){
  let apiData = {}

  // this.onTodayStatus = true
  // this.searchStatus = false
  // this.calanderStatus = false
  if(this.onTodayStatus1 == true){
    apiData = {
      storeId:this.fetchId,
      "timeframe": this.selectedValue1,
      "status": event.target.value
    }
  }

  if(this.calanderStatus1 == true){
    apiData = {
      storeId:this.fetchId,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
      "status": event.target.value
    }
  }
  console.log("data", apiData)
  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntItemDashboard', apiData, 1).subscribe((success) => {
    console.log("success==>", success)

    if (success.response_code == 200) {
      this.service.hideSpinner()
      console.log("success==>", success)

      this.totalItem = success.Data

      let totalpercentage = success.TotalPercentage

      this.chartData5 = totalpercentage.toFixed(2)

      // this.chartData1 = success.TotalPercentage

      this.chartOptions5 = {
        series: [this.chartData5],
        chart: {
          height: 120,
          type: "radialBar"
        },
        fill: {
          opacity: 1,
          colors: ['#85D8D9']
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "50%"
            }
          }
        },

        // labels: ["Financial"]
      };
      // this.usersLists = success.data.docs
      // this.usersCount = success.data.total
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}

onOrderLists(value: any) {
  this.selectedValue1 = value

  this.onTodayStatus2 = true
  this.searchStatus2 = false
  this.calanderStatus2 = false

  let apiData = {
    "storeId":this.fetchId, 
    "timeframe": value,
  }
  console.log("data", apiData)
  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntOrderDashboard', apiData, 1).subscribe((success) => {
    console.log("success==>", success)

    if (success.response_code == 200) {
      this.service.hideSpinner()
      console.log("success==>", success)

      this.totalOrder = success.Data

      let totalpercentage = success.TotalPercentage

      this.chartData2 = totalpercentage.toFixed(2)

      // this.chartData1 = success.TotalPercentage

      this.chartOptions2 = {
        series: [this.chartData2],
        chart: {
          height: 120,
          type: "radialBar"
        },
        fill: {
          opacity: 1,
          colors: ['#85D8D9']
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "50%"
            }
          }
        },

        // labels: ["Financial"]
      };
      // this.usersLists = success.data.docs
      // this.usersCount = success.data.total
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}

onItemsLists(value: any) {
  this.selectedValue1 = value

  this.onTodayStatus5 = true
  this.searchStatus5 = false
  this.calanderStatus5 = false

  let apiData = {
    storeId:this.fetchId,
    "timeframe": this.selectedValue1,
  }
  console.log("data", apiData)
  this.service.showSpinner()
  this.service.postApi('/api/v1/adminUser/restaurntItemDashboard', apiData, 1).subscribe((success) => {
    console.log("success==>", success)

    if (success.response_code == 200) {
      this.service.hideSpinner()
      console.log("success==>", success)

      this.totalItem = success.Data

      let totalpercentage = success.TotalPercentage

      this.chartData5 = totalpercentage.toFixed(2)

      // this.chartData1 = success.TotalPercentage

      this.chartOptions5 = {
        series: [this.chartData5],
        chart: {
          height: 120,
          type: "radialBar"
        },
        fill: {
          opacity: 1,
          colors: ['#85D8D9']
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "50%"
            }
          }
        },

        // labels: ["Financial"]
      };
      // this.usersLists = success.data.docs
      // this.usersCount = success.data.total
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })
}

onCalenderSearch1() {
  this.formvalidation.submitted = true
  if (this.calanderSearch1.invalid) {
    // this.onCuisinesLists()
    // this.service.err("Please enter cuisin name!")
    return
  }



  this.onTodayStatus1 = false
  this.searchStatus1 = false
  this.calanderStatus1 = true

  this.onTodayStatus2 = false
  this.searchStatus2 = false
  this.calanderStatus2 = true

  this.onTodayStatus5 = false
  this.searchStatus5 = false
  this.calanderStatus5 = true
  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



  let apiData = {
    storeId:this.fetchId,
    "startDate": new Date(this.calanderSearch1.value.startDate),
    "endDate": new Date(this.calanderSearch1.value.endDate),
  }

  console.log("data", apiData)
  this.service.showSpinner()
  // ===================================== userdashBoard ==================================================// 
  this.service.postApi('/api/v1/adminUser/userDashboard', apiData, 1).subscribe((success) => {
    // console.log("success==>",success)

    if (success.response_code == 200) {
      this.service.hideSpinner()
      this.chartStatus = true

      this.totalUsers = success.Data

      let totalpercentage = success.TotalPercentage

      this.chartData = totalpercentage.toFixed(2)

      console.log("this.chartData==>", this.chartData)

      this.chartOptions = {
        series: [this.chartData],
        chart: {
          height: 120,
          type: "radialBar"
        },
        fill: {
          opacity: 1,
          colors: ['#85D8D9']
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "50%"
            }
          }
        },

        // labels: ["Financial"]
      };
      // console.log("success==>",success)
      // this.usersLists = success.data.docs
      // this.usersCount = success.data.total
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })

  // ===================================Restaurnt Dashboard ============================================//

  this.service.postApi('/api/v1/adminUser/restaurntDashboard', apiData, 1).subscribe((success) => {
    console.log("success==>", success)

    if (success.response_code == 200) {
      this.service.hideSpinner()
      console.log("success==>", success)
      this.totalRestaurnt = success.Data


      let totalpercentage = success.TotalPercentage

      this.chartData1 = totalpercentage.toFixed(2)

      // this.chartData1 = success.TotalPercentage



      this.chartOptions1 = {
        series: [this.chartData1],
        chart: {
          height: 120,
          type: "radialBar"
        },
        fill: {
          opacity: 1,
          colors: ['#85D8D9']
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "50%"
            }
          }
        },

        // labels: ["Financial"]
      };
      // this.usersLists = success.data.docs
      // this.usersCount = success.data.total
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })

  // ===================================Order Dashboard =================================================//

  this.service.postApi('/api/v1/adminUser/restaurntOrderDashboard', apiData, 1).subscribe((success) => {
    console.log("success==>", success)

    if (success.response_code == 200) {
      this.service.hideSpinner()
      console.log("success==>", success)

      let totalpercentage = success.TotalPercentage

      this.chartData2 = totalpercentage.toFixed(2)

      // this.chartData1 = success.TotalPercentage

      this.chartOptions2 = {
        series: [this.chartData2],
        chart: {
          height: 120,
          type: "radialBar"
        },
        fill: {
          opacity: 1,
          colors: ['#85D8D9']
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "50%"
            }
          }
        },

        // labels: ["Financial"]
      };
      // this.usersLists = success.data.docs
      // this.usersCount = success.data.total
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })

  // =====================================Item Dashboard ==================================================//

  this.service.postApi('/api/v1/adminUser/restaurntItemDashboard', apiData, 1).subscribe((success) => {
    console.log("success==>", success)

    if (success.response_code == 200) {
      this.service.hideSpinner()
      console.log("success==>", success)

      this.totalItem = success.Data

      let totalpercentage = success.TotalPercentage

      this.chartData5 = totalpercentage.toFixed(2)

      // this.chartData1 = success.TotalPercentage

      this.chartOptions5 = {
        series: [this.chartData5],
        chart: {
          height: 120,
          type: "radialBar"
        },
        fill: {
          opacity: 1,
          colors: ['#85D8D9']
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "50%"
            }
          }
        },

        // labels: ["Financial"]
      };
      // this.usersLists = success.data.docs
      // this.usersCount = success.data.total
      // this.service.succ(success.message)

    }
    else {
      this.service.hideSpinner()
      this.service.err(success.message)
    }
  }, error => {
    this.service.hideSpinner()
  })




}



}
