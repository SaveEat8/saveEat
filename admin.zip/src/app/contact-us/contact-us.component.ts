import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  contentData: any
  termsData: any
  contactUsData:any
  faqs: any
  aboutUsForm: FormGroup
  termsForm: FormGroup
  contactUsForm: FormGroup

  editCheck:any = false

  constructor(public appService: AppService,
    private formBuilder: FormBuilder,
    private router: Router) {
    this.contactUsForm = this.formBuilder.group({
      companyName: ['',[Validators.required]],
      companyAddress:['',[Validators.required]],
      companyEmail:['',[Validators.required]],
      contactNumber:['',[Validators.required]],
      companyWeb:['',[Validators.required]]
    });
  }


  ngOnInit(): void {
    this.editCheck = localStorage.getItem('Edit')
    this.onGetData()
  }

  onGetData() {

    let apiData = {
      'contentId': "61123bddcec20e27cc1670c8",
    }



    console.log("data", apiData)
    this.appService.showSpinner()
    this.appService.postApi('/api/v1/adminStatic/getStaticContentByType', apiData, 1).subscribe((success) => {
      console.log("success==>", success)
      if (success.status == 200) {
        this.appService.hideSpinner()

        this.contactUsData = success.data

      }
      else {
        this.appService.hideSpinner()
        this.appService.err(success.message)
      }
    }, error => {
      this.appService.hideSpinner()
    })
  }

  onSubmit() {
    if(this.editCheck == 'false'){
      return this.appService.err("User Not allowed to perform this action")
    }
    console.log("data===>", this.contactUsForm.value.data)

    let apiData = {
      'contentId': "61123bddcec20e27cc1670c8",
      'companyName':this.contactUsForm.value.companyName,
      'companyAddress':this.contactUsForm.value.companyAddress,
      'contactNumber':this.contactUsForm.value.contactNumber,
      'webisteUrl':this.contactUsForm.value.companyWeb,
      'email':this.contactUsForm.value.companyEmail,

    }



    console.log("data", apiData)
    this.appService.showSpinner()
    this.appService.postApi('/api/v1/adminStatic/updateContentContactus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)
      if (success.status == 200) {
        this.appService.hideSpinner()
        this.appService.succ("Content Updated")

      }
      else {
        this.appService.hideSpinner()
        this.appService.err(success.message)
      }
    }, error => {
      this.appService.hideSpinner()
    })
  }

}
