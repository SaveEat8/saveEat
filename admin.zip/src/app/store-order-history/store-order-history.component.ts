import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-store-order-history',
  templateUrl: './store-order-history.component.html',
  styleUrls: ['./store-order-history.component.css']
})
export class StoreOrderHistoryComponent implements OnInit {
  profilePic:any=localStorage.getItem("profilePic")
  fetchId:any
  constructor() { }

  ngOnInit(): void {
    this.onFetchId()
  }

  onFetchId() {
    this.fetchId = localStorage.getItem("storeId")
  }

}
