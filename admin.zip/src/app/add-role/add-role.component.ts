import { Component, OnInit } from '@angular/core';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import 'lodash';

declare var _:any;


@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css']
})
export class AddRoleComponent implements OnInit {
  dropdownSettings:IDropdownSettings;
  dropdownSettings1:IDropdownSettings;
  public settings = {};
  dropdownList:any
  actionList:any
  formvalidation: any = { submitted: false }

  moduleArr:any = []
  actionArr:any = []

  actionFirstArr:any = []

  obj:any = {}

  roleCreate: any = FormGroup;

  // dropdownSettings:any = {};

  constructor(private route: Router,
    private formBuilder: FormBuilder,
    private service: AppService,
    private activatedRoute: ActivatedRoute) {
    this.roleCreate = this.formBuilder.group({
      title: ['', [Validators.required]],
      description:[''],
      actions:[''],
      module:['']
    });
   }

  ngOnInit(): void {

    this.dropdownList = [
      // 'Statistics' ,
      'Customers' ,
      'Restaurants' ,
      'Orders' ,
      'Finance' ,
      'Rewards' ,
      'Credits' ,
      'Users' ,
      'Cuisines' ,
      'Static' ,
    ];

    this.actionList = [
       'View' ,
       'Edit' ,
       'Delete' ,
       'Add' ,
       'Block' ,
    ];

    this.dropdownSettings = {
      singleSelection: false,
      // idField: 'modeule_name',
      textField: 'modeule_name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      // itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.dropdownSettings1 = {
      singleSelection: false,
      // idField: 'actionList',
      // textField: 'actionList',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      // itemsShowLimit: 3,
      allowSearchFilter: true
    };

    // this.settings = {
    //   singleSelection: false,
    //   idField: 'modeule_name',
    //   textField: 'modeule_name',
    // };
  }



  public onFilterChange(item: any) {
    console.log(item);
  }
  
  public onDropDownClose(item: any) {
    console.log(item);
  }

  public onItemSelect(item: any) {
    // this.actionFirstArr = []

    this.actionFirstArr.push(item)

    this.actionFirstArr.map((item:any) =>{
      let Obj={title :''}
      Obj.title= item
      this.moduleArr.push(Obj)
    })
    console.log('========>> this.moduleArr.', this.moduleArr)
  }

  public onDeSelect(item: any) {
    console.log(item);
   
    let isExist = this.moduleArr.find((x: { title: any; }) =>
      x.title === item
    );
  
    console.log("isExist",isExist)
  
    if (isExist) {
      _.remove(this.moduleArr, {
        title: item
      })
  
      console.log("this.moduleArr==>",this.moduleArr)
    } 
  
  }

  public onSelectAll(items: any) {
    
    // this.moduleArr = items
    // console.log(this.moduleArr);
   items
    .map((item:any) =>{
      let Obj={title :''}
      Obj.title= item
      this.moduleArr.push(Obj)
    })
    console.log('========>> this.moduleArr.', this.moduleArr)

  }

  public onDeSelectAll(items: any) {
    console.log("onDeSelectAll",items);
    this.actionFirstArr = []

    this.moduleArr = []
  }


  public onFilterChange1(item: any) {
    console.log("sfsd",item);
  }
  public onDropDownClose1(item: any) {
    console.log("scsdf",item);
  }

  public onItemSelect1(item: any) {
    console.log(item);
    var index = this.actionArr.indexOf(item);
    if (index == -1) {
      this.actionArr.push(item);
    }
    console.log("this.actionArr==>",this.actionArr)
    // this.actionArr = []
    // this.actionArr.push(item)
  }

  public onDeSelect1(item: any) {
    console.log(item);
  //   let isExist = this.actionArr.find((x:any) =>
  //   x === item
  // );

//   let isExist = this.actionArr.indexOf((x:any) =>
//   x === item
// );


var index = this.actionArr.indexOf(item);
if (index !== -1) {
  this.actionArr.splice(index, 1);
}

console.log("this.moduleArr==>",this.actionArr)

  

  // console.log("isExist",isExist)

  // if (isExist) {
  //   _.remove(this.actionArr, {
  //     item
  //   })

  // } 

  }

  public onSelectAll1(items: any) {
    console.log(items);
    this.actionArr = []
    this.actionArr = items 
  }

  public onDeSelectAll1(items: any) {
    console.log(items);
    this.actionArr = []
  }

  onCreateRole(roleCreate:any){
    this.formvalidation.submitted = true
    if (this.roleCreate.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }



    let apiData = {
      // "name": cuisinData.name,
      title: roleCreate.title,
      description:roleCreate.description,
      actions:this.actionArr,
      module:this.moduleArr
    }

    console.log("apiData==>",apiData)
    
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/createAdminRole', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        this.roleCreate.reset()
        this.route.navigate(['/role-managemnt'])
        this.service.succ(success.message)
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


}
