import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { CookieService } from 'ngx-cookie-service'
declare function password():any;
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  
  formvalidation: any = { submitted: false }
  resetForm: any = FormGroup
  constructor(
    private route: Router,
    private activatedRoute: ActivatedRoute,
    private service: AppService,
    private cookieService: CookieService
  ) {
    if (localStorage.getItem('forgotId') == undefined || localStorage.getItem('forgotId') == '') {
      this.service.err("You do'nt have permission to acess this page.")
      this.route.navigate(['/'])
      return
    }
  }

  ngOnInit(): void {
    this.resetForm = new FormGroup({
      password: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]),
      confirmPassword: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]),
    });
    password()
  }


  resetFunction(data: any) {

    this.formvalidation.submitted = true
    if (this.resetForm.invalid) {
      return
    }
    if (data.password !== data.confirmPassword) {
      this.service.err("Confirm password should be match with password.")
      return
    }
    let apiData = {
      password: data.password,
      adminId: localStorage.getItem("forgotId"),
    }

    this.service.postApi('/api/v1/admin/resetPassword', apiData, 0).subscribe((success) => {
      if (success.status == 200) {
        this.service.succ(success.message)
        localStorage.removeItem("forgotId")
        this.route.navigate(['/login'])
      }
      else {
        this.service.err(success.message)
      }
    }, error => {

    })
  }

}
