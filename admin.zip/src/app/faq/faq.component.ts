import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service'
import { Router } from '@angular/router';
// import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {
  public Editor: any = ClassicEditor;

  contentData: any
  termsData: any
  faqs: any
  aboutUsForm: FormGroup
  termsForm: FormGroup
  faqForm: FormGroup

  constructor(public appService: AppService,
    private formBuilder: FormBuilder,
    private router: Router) {
    this.aboutUsForm = this.formBuilder.group({
      data: ['']
    });
  }

  ngOnInit(): void {
  }
  

  onSubmit() {
    console.log("data===>", this.aboutUsForm.value.data)
  }

}
