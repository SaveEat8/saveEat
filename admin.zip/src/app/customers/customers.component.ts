import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import * as xlsx from 'xlsx';
declare var $:any

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 50;
  usersLists:any = []
  usersCount:any
  brandLists:any = []
  brandsCount:any
  brandId:any
  getBrandId:any
  restaurantId:any
  search:any = FormGroup;
  calanderSearch:any = FormGroup;
  formvalidation: any = { submitted: false }
  selectedValue :any 

  onTodayStatus:any = true
  searchStatus:any = false
  calanderStatus:any = false 
  userId:any
  selectAll:any = true

  viewCheck:any = false
  editCheck:any = false
  blockCheck:any = false

  adminType= localStorage.getItem('userType');


  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {

      this.search = this.formBuilder.group({
        search: ['', [Validators.required]]
      });

      this.calanderSearch = this.formBuilder.group({
        startDate: ['', [Validators.required]],
        endDate: ['', [Validators.required]]
      });
      
     }

  ngOnInit(): void {
    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')
    console.log("this.viewCheck==>",this.viewCheck)
    console.log("this.viewCheck==>",this.editCheck)

    

       localStorage.removeItem("coustmerId");
        // this.onRestaurantsLists()
        // this.onToday('Today')
        // localStorage.removeItem("Id");
        // localStorage.removeItem("storeId");
        this.onFullPrice()
  }

  onUsersLists(){

    let apiData = {
      pageNumber:this.p

    }
    // userNumber
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onUsersListsPagination(event:any){
    this.p = event
    this.selectAll = false

    let apiData
    // this.onTodayStatus = false
    // this.searchStatus = false
    // this.calanderStatus = false 

    if(this.onTodayStatus == true){
       apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "timeframe": this.selectedValue,
      }
    }

    if(this.searchStatus == true){
      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
      }
    }

    if(this.calanderStatus == true){

      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }



    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
              // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  
  onUsersListsPagination1(event:any, status:any){
    this.p = event
    this.selectAll = status

    let apiData : any = {
      pageNumber:this.p,
      limit: this.itemPerPage
    }
    // this.onTodayStatus = false
    // this.searchStatus = false
    // this.calanderStatus = false 

    if(this.onTodayStatus == true){
       apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "timeframe": this.selectedValue,
      }
    }

    if(this.searchStatus == true){
      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
      }
    }

    if(this.calanderStatus == true){

      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }



    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
              // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch(){

    // this.selectAll = false
    this.searchStatus = true

    this.p = 1
    this.formvalidation.submitted = true
    // if (this.search.invalid) {
    //   // this.onFullPrice()
    //   // this.onToday(this.selectedValue)
    //   // this.service.err("Please enter cuisin name!")
    //   return
    // }


    let apiData = {
      
    }

    // this.onTodayStatus = false
    // this.searchStatus = true
    // this.calanderStatus = false 

    if(this.calanderStatus == true){
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }

    if(this.onTodayStatus ==true){
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        "timeframe": this.selectedValue,

      }
    }


    if(this.selectAll == true ){
      apiData = {
        pageNumber: this.p,
        limit: 100,
        "search": this.search.value.search,
        // "timeframe": this.selectedValue,

      }
    }



    console.log("apiData==>",apiData)

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  exportToExcel() {
    // const ws: xlsx.WorkSheet =
    // xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    // const wb: xlsx.WorkBook = xlsx.utils.book_new();
    // xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    // xlsx.writeFile(wb, 'restaurantList.xlsx');

    let apiData 
    // this.onTodayStatus = false

    if(this.onTodayStatus == true){
      apiData = {
       "timeframe": this.selectedValue,
     }
   }

   if(this.calanderStatus == true){
    apiData = {
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }
  }

  if(this.searchStatus == true){
    apiData = {
      "search": this.search.value.search,
    }
  }

//   if(this.onshowAll == true){
//     apiData = {
//      "search": this.search.value.search,
//      "fullPrice": "fullPrice",
//    }
//  }
console.log("apiData==>",apiData)
console.log("this.search.value.search==>",this.searchStatus)

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userDownloadList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("linkk==>",success.data)
        window.open(success.data);
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCalenderSearch(){
    this.p = 1
    this.selectAll = false
    this.searchStatus = false


    this.formvalidation.submitted = true

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true 

    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total

        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(value:any){
    this.selectedValue = value
    this.p = 1

    this.onTodayStatus = true
    this.searchStatus = false
    this.calanderStatus = false 
    this.selectAll = false


    let apiData = {
      pageNumber:this.p,
      limit:this.itemPerPage,
      "timeframe": value,

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetUserId(id:any){
    this.userId = id
  }

  onActiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {
      userId: this.userId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateUserStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()
        this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      userId: this.userId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateUserStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onFullPrice(){
    this.p = 1

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = false 
    this.selectAll = true

    let apiData = {
      pageNumber:this.p,
      limit:100,
      "timeframe": "All",

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total


        // let apiData1 =  {
        //   pageNumber:this.p,
        //   limit:100,
        //   "timeframe": "All",
    
        // }

        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCheckUser(id:any){

    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/customers-details',id])

    // /customers-details
  }

  onCheckUserCreditHistory(id:any){

    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/user-credit-history',id])

  }



}
