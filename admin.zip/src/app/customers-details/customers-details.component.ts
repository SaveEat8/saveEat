import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';


@Component({
  selector: 'app-customers-details',
  templateUrl: './customers-details.component.html',
  styleUrls: ['./customers-details.component.css']
})
export class CustomersDetailsComponent implements OnInit {

  p: any = 1;
  p1: any = 1;

  total:any = Number;
  itemPerPage: any = 40;
  pages :any;

  id:any;
  restaurantData:any
  openingTime:any
  holidays:any

  orderData:any = []
  totalOrder:any
  selectedValue :any = 'Today'
  onTodayStatus: any = true
  searchStatus: any = false
  calanderStatus: any = false

  search: any = FormGroup;
  calanderSearch: any = FormGroup;
  formvalidation: any = { submitted: false }

  userId:any
  usersLists:any = []
  usersCount:any = 0

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {

      this.search = this.formBuilder.group({
        search: ['', [Validators.required]]
      });

      this.calanderSearch = this.formBuilder.group({
        startDate: ['', [Validators.required]],
        endDate: ['', [Validators.required]]
      });

     }

  ngOnInit(): void {
    localStorage.removeItem("restorentId");
    localStorage.removeItem("storeId");
    if(localStorage.getItem("coustmerId")){
      this.id = localStorage.getItem("coustmerId")
      this.onUserDetail()
      // this.onOrderList()
      this.onToday('Today')
      // this.onUsersLists()

    }else{
      this.getId()
    }
  }


  getId() {
    this.activatedRoute.params.subscribe((paramsId) => {
      this.id = paramsId.id
      console.log('Check',this.id)
      localStorage.setItem("coustmerId",this.id)
    })

    this.onUserDetail()
    this.onTodayStatus = true
    this.onOrderList()

    // this.onUsersLists()

    // this.onToday('Today')

  }

  onUserDetail(){
    let apiData = {
      userId:this.id,
    }
    console.log("data",apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/customersDetail', apiData, 1).subscribe((success) => {
      console.log("success==>",success)
      if (success.status == 200) {
        console.log("success==>",success)
        this.restaurantData = success.data[0]
        // this.openingTime = success.Openings
        // this.holidays = success.Holidays
      }
      else {
        this.service.hideSpinner()
        // this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  // ======================================= User Order List ========================================= // 

  onOrderList(){
    let apiData = {
      userId:this.id,
      limit: this.itemPerPage,

    }
    this.onTodayStatus = true

    console.log("data",apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/userOrderList', apiData, 1).subscribe((success) => {
      console.log("orderList111==>",success)
      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("orderList==>",success)
        console.log("this.orderData===>",this.orderData.length)

        this.orderData = success.Data
        this.totalOrder = success.Total
        // this.openingTime = success.Openings
        // this.holidays = success.Holidays
      }
      else {
        this.service.hideSpinner()
        // this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  onOrderListPagination(){
    let apiData = {
      userId:this.id
    }
    this.onTodayStatus = true

    console.log("data",apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/userOrderList', apiData, 1).subscribe((success) => {
      console.log("orderList111==>",success)
      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("orderList==>",success)
        console.log("this.orderData===>",this.orderData.length)

        this.orderData = success.Data
        this.totalOrder = success.Total
        // this.openingTime = success.Openings
        // this.holidays = success.Holidays
      }
      else {
        this.service.hideSpinner()
        // this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onOrderListsPagination(event:any){
    this.p = event
    let apiData
    // this.onTodayStatus = false
    // this.searchStatus = false
    // this.calanderStatus = false 

    if(this.onTodayStatus == true){
       apiData = {
        pageNumber:this.p,
        userId:this.id,
        limit: this.itemPerPage,
        "timeframe": this.selectedValue,
      }
    }

    if(this.searchStatus == true){
      apiData = {
        pageNumber:this.p,
        userId:this.id,
        limit: this.itemPerPage,
        "search": this.search.value.search,
      }
    }

    if(this.calanderStatus == true){

      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        userId:this.id,
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }



    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userOrderList', apiData, 1).subscribe((success) => {
      console.log("orderList111==>",success)
      if (success.response_code == 200) {
        this.service.hideSpinner()

        console.log("orderList==>",success)
        this.orderData = success.Data
        this.totalOrder = success.Total
        // this.openingTime = success.Openings
        // this.holidays = success.Holidays
      }
      else {
        this.service.hideSpinner()
        // this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  onSearch(){

    this.p = 1
    this.formvalidation.submitted = true
    if (this.search.invalid) {
      this.onToday(this.selectedValue)
      // this.service.err("Please enter cuisin name!")
      return
    }


    let apiData = {
      
    }

    // this.onTodayStatus = false
    // this.searchStatus = true
    // this.calanderStatus = false 

    if(this.calanderStatus == true){
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }

    if(this.onTodayStatus ==true){
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        "timeframe": this.selectedValue,

      }
    }


    console.log("apiData==>",apiData)

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userOrderList', apiData, 1).subscribe((success) => {
      console.log("orderList111==>",success)
      if (success.response_code == 200) {
        this.service.hideSpinner()

        console.log("orderList==>",success)
        console.log("this.orderData===>",this.orderData.length)

        this.orderData = success.Data
        this.totalOrder = success.Total
        // this.openingTime = success.Openings
        // this.holidays = success.Holidays
      }
      else {
        this.service.hideSpinner()
        // this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCalenderSearch(){
    this.p = 1
    this.formvalidation.submitted = true

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true 

    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      userId:this.id,
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userOrderList', apiData, 1).subscribe((success) => {
      console.log("orderList111==>",success)
      if (success.response_code == 200) {
        this.service.hideSpinner()

        console.log("orderList==>",success)
        console.log("this.orderData===>",this.orderData.length)

        this.orderData = success.Data
        this.totalOrder = success.Total
        // this.openingTime = success.Openings
        // this.holidays = success.Holidays
      }
      else {
        this.service.hideSpinner()
        // this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(value:any){
    this.selectedValue = value
    this.p = 1

    this.onTodayStatus = true
    this.searchStatus = false
    this.calanderStatus = false 

    let apiData = {
      userId:this.id,
      pageNumber:this.p,
      limit:this.itemPerPage,
      "timeframe": value,

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userOrderList', apiData, 1).subscribe((success) => {
      console.log("orderList111==>",success)
      if (success.response_code == 200) {
        this.service.hideSpinner()

        console.log("orderList==>",success)
        console.log("this.orderData===>",this.orderData.length)

        this.orderData = success.Data
        this.totalOrder = success.Total
        // this.openingTime = success.Openings
        // this.holidays = success.Holidays
      }
      else {
        this.service.hideSpinner()
        // this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }




  onUsersLists(){

    let apiData = {
      "userId":this.id,
      pageNumber:this.p1,
      // creditType:"Direct"
    }
    // userNumber
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onUserCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onUsersListsPagination(event:any){
    this.p1 = event
    let apiData
    // this.onTodayStatus = false
    // this.searchStatus = false
    // this.calanderStatus = false 

    // if(this.onTodayStatus == true){
    //    apiData = {
    //     "userId":this.id,
    //     pageNumber:this.p,
    //     limit: this.itemPerPage,
    //     // "timeframe": this.selectedValue,
    //   }
    // }

    // if(this.searchStatus == true){
    //   apiData = {
    //     pageNumber:this.p,
    //     limit: this.itemPerPage,
    //     "userId":this.id,
    //     creditType:"Direct",
    //     "search": this.search.value.search,
    //   }
    // }


      apiData = {
        pageNumber:this.p,
        "userId":this.id,
        limit: this.itemPerPage,
        // "startDate": new Date(this.calanderSearch.value.startDate),
        // creditType:"Direct",
        // "endDate": new Date(this.calanderSearch.value.endDate),
      }

    



    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onUserCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total

              // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onclose(){
    this.p1 = 1
  }



}
