import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-delivery-fee',
  templateUrl: './delivery-fee.component.html',
  styleUrls: ['./delivery-fee.component.css']
})
export class DeliveryFeeComponent implements OnInit {

  myForm: any = FormGroup;

  constructor(
    public router: Router,
    private activatedRoute: ActivatedRoute,
    public service: AppService,
    public domSanitizer: DomSanitizer,
  ) { }

  ngOnInit(): void {
    this.onGetDeliveryDetails()

    this.myForm = new FormGroup({
      zero_one: new FormControl('', [Validators.required]),
      one_two: new FormControl('', [Validators.required]),
      two_three: new FormControl('', [Validators.required]),
      three_four: new FormControl('', [Validators.required]),
      four_five: new FormControl('', [Validators.required]),
      five_six: new FormControl('', [Validators.required]),
      six_seven: new FormControl('', [Validators.required]),
      seven_eight: new FormControl('', [Validators.required]),
      eight_nine: new FormControl('', [Validators.required]),
      nine_ten: new FormControl('', [Validators.required]),
    })

  }
  
  onGetDeliveryDetails() {

    let apireq = {}
    this.service.postApi('/api/v1/admin/getDeliveryDetails', apireq, 1).subscribe(success => {
      // console.log("success==>", success)
      if (success.status == 200) {
        this.myForm.controls['zero_one'].setValue(success.data.zero_one);
        this.myForm.controls['one_two'].setValue(success.data.one_two);
        this.myForm.controls['two_three'].setValue(success.data.two_three);
        this.myForm.controls['three_four'].setValue(success.data.three_four);
        this.myForm.controls['four_five'].setValue(success.data.four_five);
        this.myForm.controls['five_six'].setValue(success.data.five_six);
        this.myForm.controls['six_seven'].setValue(success.data.six_seven);
        this.myForm.controls['seven_eight'].setValue(success.data.seven_eight);
        this.myForm.controls['eight_nine'].setValue(success.data.eight_nine);
        this.myForm.controls['nine_ten'].setValue(success.data.nine_ten);
      } else {
        this.service.err(success.message);
      }
    }, error => {
      console.log("Something went wrong")
    })
  }

  onUpdateDeliveryFee(data:any){
    
    let apireq = {
      zero_one: data.zero_one,
      one_two: data.one_two,
      two_three: data.two_three,
      three_four: data.three_four,
      four_five: data.four_five,
      five_six: data.five_six,
      six_seven: data.six_seven,
      seven_eight: data.seven_eight,
      eight_nine: data.eight_nine,
      nine_ten: data.nine_ten
    }
    this.service.postApi('/api/v1/admin/updateDeliveryFee', apireq, 1).subscribe(success => {
      if (success.status == 200) {
        this.service.succ(success.message);
      }
      else {
        this.service.err(success.message);
      }
    }, error => {
      console.log("Something went wrong")
    })
  }

}
