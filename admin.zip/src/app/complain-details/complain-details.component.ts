import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complain-details',
  templateUrl: './complain-details.component.html',
  styleUrls: ['./complain-details.component.css']
})
export class ComplainDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
