import { Component, HostListener, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AppService } from '../app.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
declare var $: any;
declare function otp():any;
@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css']
})
export class OtpComponent implements OnInit {

  email: any = localStorage.getItem("email")
  otpForm: any = FormGroup
  otp: any = 0
  constructor(
    public service: AppService,
    public route: Router,
    private _location: Location,
    private http: HttpClient,
    public router: Router,
  ) {
    if (localStorage.getItem('email') == undefined || localStorage.getItem('email') == '') {
      this.service.err("You do'nt have permission to acess this page.")
      this.router.navigate(['/'])
      return
    }
  }

  ngOnInit(): void {
    otp()
  }

  onOtpChange(e: any) {

    this.otp = e
  }

  onSubmit() {

    if (this.otp.length !== 6) {
      this.service.err("Please enter valid OTP!")
      return
    }
    let data = {
      otp: this.otp,
      email: localStorage.getItem('email')
    }
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/verifyOtp', data, 0).subscribe(success => {
      if (success.status == 200) {
        this.service.hideSpinner()
        localStorage.removeItem("email")
        this.service.succ(success.message)
        this.route.navigate(['/reset-password'])
        localStorage.setItem("forgotId",success.data)
      }
      else {
        this.service.err(success.message)
        this.service.hideSpinner()
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  resendOtp() {
    if (localStorage.getItem("email")) {
      let data = {
        email: localStorage.getItem('email')
      }
      this.service.showSpinner()
      this.service.postApi('/api/v1/admin/adminForgotPassword', data, 0).subscribe(success => {
        if (success.status == 200) {
          this.service.hideSpinner()
          this.service.succ(success.message)
        }
        else {
          this.service.err(success.message)
          this.service.hideSpinner()
        }
      }, error => {
        this.service.hideSpinner()
      })
    }
    else {
      this.service.err("Can not resend otp now. Please wait a moment.")
    }

  }


}
