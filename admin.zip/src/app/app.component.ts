// import { Component, OnInit } from '@angular/core';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

// export class AppComponent implements OnInit {
//   title = 'save-eat-admin';

//   ngOnInit(): void {
//     if (window.location.protocol == 'http:') { 
//       window.open('https://saveeat.in/admin','_self');
//     }
//   }
// }

export class AppComponent {
  title = 'save-eat-admin';

  // ngOnInit(): void {
  //   if (window.location.protocol == 'http:') { 
  //     window.open('https://saveeat.in/','_self');
  //   }
  // }
}

