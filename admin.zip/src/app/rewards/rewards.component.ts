import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
declare var $:any

@Component({
  selector: 'app-rewards',
  templateUrl: './rewards.component.html',
  styleUrls: ['./rewards.component.css']
})
export class RewardsComponent implements OnInit {

  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 10;
  restaurantsLists:any = []
  restaurantsCount:any
  brandLists:any = []
  brandsCount:any
  brandId:any
  getBrandId:any
  restaurantId:any
  search:any = FormGroup;
  calanderSearch:any = FormGroup;
  formvalidation: any = { submitted: false }
  selectedValue :any = 'Today'
  profilePic:any=localStorage.getItem("profilePic")
  

  onTodayStatus:any = true
  searchStatus:any = false
  calanderStatus:any = false 

  viewCheck:any = false
  editCheck:any = false

  constructor( private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {
      this.search = this.formBuilder.group({
        search: ['', [Validators.required]]
      });

      this.calanderSearch = this.formBuilder.group({
        startDate: ['', [Validators.required]],
        endDate: ['', [Validators.required]]
      });
     }

  ngOnInit(): void {
    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')

    console.log("this.viewCheck==>",this.viewCheck)
    console.log("this.editCheck==>",this.editCheck)

    localStorage.removeItem("restorentId");
    localStorage.removeItem("storeId");
    this.onToday('Today')
  }

  onRestaurantsLists(){

    let apiData = {
      pageNumber:this.p

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onRewardList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.data
        this.restaurantsCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRestaurantsListsPagination(event:any){
    this.p = event
    // let apiData = {
    //   pageNumber:this.p

    // }
    let apiData 

    if(this.onTodayStatus == true){
      apiData = {
       pageNumber:this.p,
       limit: this.itemPerPage,
       "timeframe": this.selectedValue,
     }
   }

   if(this.searchStatus == true){
     apiData = {
       pageNumber:this.p,
       limit: this.itemPerPage,
       "search": this.search.value.search,
     }
   }

   if(this.calanderStatus == true){

     apiData = {
       pageNumber:this.p,
       limit: this.itemPerPage,
       "startDate": new Date(this.calanderSearch.value.startDate),
       "endDate": new Date(this.calanderSearch.value.endDate),
     }

   }


    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onRewardList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.data
        this.restaurantsCount = success.total

        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch(){
    this.p = 1
    this.formvalidation.submitted = true
    if (this.search.invalid) {
      this.onToday(this.selectedValue)
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus = false
    this.searchStatus = true
    this.calanderStatus = false 

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "search": this.search.value.search,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onRewardList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.data
        this.restaurantsCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCalenderSearch(){
    this.p = 1
    this.formvalidation.submitted = true
    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true 

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onRewardList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.data
        this.restaurantsCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(value:any){
    this.selectedValue = value
    this.p = 1

    let apiData = {
      pageNumber:this.p,
      limit: this.itemPerPage,
      "timeframe": value,
    }

    this.onTodayStatus = true
    this.searchStatus = false
    this.calanderStatus = false 

    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onRewardList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.data
        console.log("this.restaurantsLists==>",this.restaurantsLists.length)
        this.restaurantsCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }



  onGetRestaurentId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/restaurants-personal-information',id])
  }

  onGetOrderDetailId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/refund-already',id])
  }

  onGetCustomerDetailId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/customers-details',id])
  }

  onGetReward(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/reward-history',id])
  }

}
