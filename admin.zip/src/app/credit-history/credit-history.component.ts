import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';

@Component({
  selector: 'app-credit-history',
  templateUrl: './credit-history.component.html',
  styleUrls: ['./credit-history.component.css']
})
export class CreditHistoryComponent implements OnInit {

  id:any;

  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 50;
  usersLists:any = []
  usersCount:any
  brandLists:any = []
  brandsCount:any
  brandId:any
  getBrandId:any
  restaurantId:any
  search:any = FormGroup;
  calanderSearch:any = FormGroup;
  formvalidation: any = { submitted: false }
  selectedValue :any = 'Today'

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute
    ) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe((paramsId) => {
      this.id = paramsId.id
      console.log('Check',this.id)
    })

    this.onToday()
  }


  onToday(){
    this.p = 1

    let apiData = {
      couponId:this.id,
      pageNumber:this.p,
      limit:this.itemPerPage,
      // creditType:"Code"

      // "timeframe": value,
    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userCreditHistory', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


    onUsersListsPagination(event:any){
    this.p = event
    // this.onTodayStatus = false
    // this.searchStatus = false
    // this.calanderStatus = false 


    let apiData = {
      couponId:this.id,
      pageNumber:this.p,
      limit:this.itemPerPage,
      // creditType:"Code"

      // "timeframe": value,
    }


    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
              // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

}
