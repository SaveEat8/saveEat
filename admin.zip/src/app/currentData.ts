export class Current {
    
    profileData:any=localStorage.getItem("profilePic");
    name:any=localStorage.getItem("name")
   

    constructor() {
    }
}