import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';

@Component({
  selector: 'app-wallet-history',
  templateUrl: './wallet-history.component.html',
  styleUrls: ['./wallet-history.component.css']
})
export class WalletHistoryComponent implements OnInit {

  waletHistoryLists: any
  id : any

  constructor(
    private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    // this.onHistoryLists()
    this.getId()
  }

  getId() {
    this.activatedRoute.params.subscribe((paramsId) => {
      this.id = paramsId.id
      console.log('Check',this.id)
    })

    this.onHistoryLists()

  }

  onHistoryLists(){

    let apiData = {
      brandId:this.id

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/brandWalletHistory', apiData, 1).subscribe((success) => {
      console.log("success==>",success)
      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.waletHistoryLists = success.data
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

}
