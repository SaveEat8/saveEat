import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
declare function Animate():any;
@Component({
  selector: 'app-adminbar',
  templateUrl: './adminbar.component.html',
  styleUrls: ['./adminbar.component.css']
})
export class AdminbarComponent implements OnInit {


  name:any=localStorage.getItem("name")
  profilePic:any=localStorage.getItem("profilePic")
  constructor(
    public router : Router,
    private activatedRoute: ActivatedRoute,
    public service :AppService
  ) { }

  ngOnInit(): void {
    Animate();
  }

  logout() {

    let apireq = {
    adminId: localStorage.getItem("superId")

    }
    this.service.postApi('/api/v1/admin/adminLogout', apireq, 0).subscribe(success => {
      if (success.status == 200) {
        this.service.succ(success.message);
        localStorage.clear()
        this.router.navigate(['/'])
      }
      else {
        this.service.err(success.message);
      }
    }, error => {
      console.log("Something went wrong")
    })
  }

}
