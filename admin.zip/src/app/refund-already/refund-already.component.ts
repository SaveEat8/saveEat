import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import * as xlsx from 'xlsx';
declare var $:any

@Component({
  selector: 'app-refund-already',
  templateUrl: './refund-already.component.html',
  styleUrls: ['./refund-already.component.css']
})
export class RefundAlreadyComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  id:any;
  userId:any;
  restaurantData:any
  openingTime:any
  holidays:any
  storeId:any
  refundCreate:any = FormGroup;
  formvalidation: any = { submitted: false }

  totalPayamount:any = 0
  addCheck:any = false

  onlinePaidAmount:any
  onlinePaidAmount1:any


  amountStatus:any = false

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {

      this.refundCreate = this.formBuilder.group({
        reason: ['', [Validators.required]],
        refundType:['',[Validators.required]],
        refundedBy:['',[Validators.required]],
        refundAmount:['',[Validators.required]]
      });

     }

  ngOnInit(): void {
    localStorage.removeItem("restorentId");
    localStorage.removeItem("storeId");
    localStorage.removeItem("coustmerId");
    this.addCheck = localStorage.getItem('Add')
    this.getId()
  }


  getId() {
    this.activatedRoute.params.subscribe((paramsId) => {
      this.id = paramsId.id
      console.log('Check',this.id)
      localStorage.setItem("restorentId",this.id)
    })

    this.onRestaurantDetail()

  }

  onRestaurantDetail(){
    let apiData = {
      orderId:this.id
    }
    console.log("data",apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/particularOrderAmin', apiData, 1).subscribe((success) => {
      console.log("success==>",success)
      if (success.response_code == 200) {
        console.log("success==>",success)
        this.restaurantData = success.Data[0]
        this.userId = this.restaurantData.usersDetail[0]._id
        this.storeId = this.restaurantData.storeId
        console.log("this.storeId===>",this.storeId)
        console.log("this.restaurantData==>",this.restaurantData)
        this.totalPayamount = this.restaurantData.total

        this.onlinePaidAmount1 = (Number(success.Data[0].total)-Number(success.Data[0].deductedPoints)).toFixed(2);

        this.onlinePaidAmount = Math.abs(this.onlinePaidAmount1)
        
        if(this.onlinePaidAmount1 < 0){
          this.amountStatus = true
        }

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  exportToExcel() {
    const ws: xlsx.WorkSheet =
    xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'itemDetails.xlsx');
  }

  onRefundAmount(){

    if(this.addCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.formvalidation.submitted = true
    if (this.refundCreate.invalid) {
      // console.log("invalid==>",this.refundCreate.value)
      // this.service.err("Please enter cuisin name!")
      return
    }

    if(this.refundCreate.value.refundAmount > this.totalPayamount){
     return this.service.err("You cannot pay more then ordered amount")
    }

    let apiData = {
      "adminId":localStorage.getItem("superId"),
      "userId": this.userId,
      "orderId":this.id,
      "storeId":this.storeId,
      "reason": this.refundCreate.value.reason,
      "refundType": this.refundCreate.value.refundType,
      "refundedBy": this.refundCreate.value.refundedBy,
      "refundAmount": this.refundCreate.value.refundAmount,


    }
    console.log("apiData",apiData)
    
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onMakeRefund', apiData, 0).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.onRestaurantDetail()

        $("#refund").modal("hide");

        this.route.navigate(['/credit-transation'])

        

        console.log("success Check==>", success)
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }


}
