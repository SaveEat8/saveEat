import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
declare var $: any

import {
  ApexNonAxisChartSeries,
  ApexPlotOptions,
  ApexChart,
  ApexFill
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  fill: ApexFill;
  labels: string[];
  plotOptions: ApexPlotOptions;
};



@Component({
  selector: 'app-dashborad',
  templateUrl: './dashborad.component.html',
  styleUrls: ['./dashborad.component.css']
})
export class DashboradComponent implements OnInit {
  // @ViewChild("chart") chart: ChartComponent | any;
  public chartOptions: Partial<ChartOptions> | any;
  public chartOptions1: Partial<ChartOptions> | any;
  public chartOptions2: Partial<ChartOptions> | any;
  public chartOptions3: Partial<ChartOptions> | any;
  public chartOptions4: Partial<ChartOptions> | any;
  public chartOptions5: Partial<ChartOptions> | any;
  public chartOptions6: Partial<ChartOptions> | any;
  public chartOptions7: Partial<ChartOptions> | any;







  profilePic: any = localStorage.getItem("profilePic")



  formvalidation: any = { submitted: false }
  selectedValue: any = 'Today'

  totalUsers: any = 0
  totalRestaurnt: any = 0
  totalOrder: any = 0
  totalItem: any = 0

  financeItem: any = 0
  creditItem: any = 0

  selectedUsers: any
  percentageUsers: any

  onTodayStatus: any = true
  searchStatus: any = false
  calanderStatus: any = false

  onTodayStatus1: any = true
  searchStatus1: any = false
  calanderStatus1: any = false

  onTodayStatus2: any = true
  searchStatus2: any = false
  calanderStatus2: any = false

  onTodayStatus5: any = true
  searchStatus5: any = false
  calanderStatus5: any = false

  chartStatus: any = false
  userId: any

  chartData: any = 40
  chartData1: any = 40
  chartData2: any = 40
  chartData3: any = 0
  chartData4: any = 0
  chartData5: any = 0
  chartData6: any = 0
  chartData7: any = 0


  chartData10: any = 0
  rewardItem: any = 0
  savedItem: any = 0





  calanderSearch: any = FormGroup;


  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {

    this.calanderSearch = this.formBuilder.group({
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]]
    });

    this.chartOptions = {
      series: [this.chartData],
      chart: {
        height: 120,
        type: "radialBar"
      },
      fill: {
        opacity: 1,
        colors: ['#85D8D9']
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: "50%"
          }
        }
      },

      // labels: ["Financial"]
    };

    this.chartOptions1 = {
      series: [this.chartData1],
      chart: {
        height: 120,
        type: "radialBar"
      },
      fill: {
        opacity: 1,
        colors: ['#85D8D9']
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: "50%"
          }
        }
      },

      // labels: ["Financial"]
    };

    this.chartOptions2 = {
      series: [this.chartData2],
      chart: {
        height: 120,
        type: "radialBar"
      },
      fill: {
        opacity: 1,
        colors: ['#85D8D9']
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: "50%"
          }
        }
      },

      // labels: ["Financial"]
    };

    this.chartOptions3 = {
      series: [this.chartData3],
      chart: {
        height: 120,
        type: "radialBar"
      },
      fill: {
        opacity: 1,
        colors: ['#85D8D9']
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: "50%"
          }
        }
      },

      // labels: ["Financial"]
    };

    this.chartOptions4 = {
      series: [this.chartData4],
      chart: {
        height: 120,
        type: "radialBar"
      },
      fill: {
        opacity: 1,
        colors: ['#85D8D9']
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: "50%"
          }
        }
      },

      // labels: ["Financial"]
    };

    this.chartOptions5 = {
      series: [this.chartData5],
      chart: {
        height: 120,
        type: "radialBar"
      },
      fill: {
        opacity: 1,
        colors: ['#85D8D9']
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: "50%"
          }
        }
      },

      // labels: ["Financial"]
    };

    this.chartOptions6 = {
      series: [this.chartData6],
      chart: {
        height: 120,
        type: "radialBar"
      },
      fill: {
        opacity: 1,
        colors: ['#85D8D9']
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: "50%"
          }
        }
      },

      // labels: ["Financial"]
    };

    this.chartOptions7 = {
      series: [this.chartData7],
      chart: {
        height: 120,
        type: "radialBar"
      },
      fill: {
        opacity: 1,
        colors: ['#85D8D9']
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: "50%"
          }
        }
      },

      // labels: ["Financial"]
    };

  }

  ngOnInit(): void {
    this.onToday('Today')
  }

  onToday(value: any) {
    this.selectedValue = value

    this.onUsersLists(value)
    this.onRestaurntLists(value)
    this.onOrderLists(value)
    this.onItemsLists(value)

    this.onfinanceLists(value)
    this.creditDashboard(value)
    this.rewardDashboard(value)
    this.savedDashboard(value)
  }



  onUsersLists(value: any) {
    this.selectedValue = value

    this.onTodayStatus = true
    this.searchStatus = false
    this.calanderStatus = false

    let apiData = {
      "timeframe": value,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userDashboard', apiData, 1).subscribe((success) => {
      // console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        this.chartStatus = true



        let totalpercentage = success.TotalPercentage

        this.totalUsers = success.Data

        this.chartData = totalpercentage.toFixed(2)

        console.log("this.chartData==>", this.chartData)

        this.chartOptions = {
          series: [this.chartData],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // console.log("success==>",success)
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRestaurntLists(value: any) {
    this.selectedValue = value

    this.onTodayStatus1 = true
    this.searchStatus1 = false
    this.calanderStatus1 = false

    let apiData = {
      "timeframe": value,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurntDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.totalRestaurnt = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData1 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage



        this.chartOptions1 = {
          series: [this.chartData1],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onOrderLists(value: any) {
    this.selectedValue = value

    this.onTodayStatus2 = true
    this.searchStatus2 = false
    this.calanderStatus2 = false

    let apiData = {
      "timeframe": value,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/orderDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.totalOrder = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData2 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions2 = {
          series: [this.chartData2],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onItemsLists(value: any) {
    this.selectedValue = value

    this.onTodayStatus5 = true
    this.searchStatus5 = false
    this.calanderStatus5 = false

    let apiData = {
      "timeframe": value,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/itemDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.totalItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData5 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions5 = {
          series: [this.chartData5],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onfinanceLists(value: any) {
    this.selectedValue = value

    this.onTodayStatus5 = true
    this.searchStatus5 = false
    this.calanderStatus5 = false

    let apiData = {
      "timeframe": value,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/financeDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.financeItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData7 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions7 = {
          series: [this.chartData7],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  creditDashboard(value: any) {
    this.selectedValue = value

    this.onTodayStatus5 = true
    this.searchStatus5 = false
    this.calanderStatus5 = false

    let apiData = {
      "timeframe": value,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/creditDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.creditItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData10 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions4 = {
          series: [this.chartData10],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  rewardDashboard(value: any) {
    this.selectedValue = value

    this.onTodayStatus5 = true
    this.searchStatus5 = false
    this.calanderStatus5 = false

    let apiData = {
      "timeframe": value,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/rewardDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.rewardItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData3 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions3 = {
          series: [this.chartData3],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  savedDashboard(value: any) {
    this.selectedValue = value

    this.onTodayStatus5 = true
    this.searchStatus5 = false
    this.calanderStatus5 = false

    let apiData = {
      "timeframe": value,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/savedDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.savedItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData6 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions6 = {
          series: [this.chartData6],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }





  onCalenderSearch() {
    this.formvalidation.submitted = true
    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true

    this.onTodayStatus1 = false
    this.searchStatus1 = false
    this.calanderStatus1 = true

    this.onTodayStatus2 = false
    this.searchStatus2 = false
    this.calanderStatus2 = true

    this.onTodayStatus5 = false
    this.searchStatus5 = false
    this.calanderStatus5 = true
    //   let startDate =  new Date(this.calanderSearch.value.startDate);
    //   let endDate = new Date(this.calanderSearch.value.endDate);

    //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
    //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


    //   let startDates = new Date(updatedStartDate)
    //   let endDates = new Date()



    let apiData = {
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    // ===================================== userdashBoard ==================================================// 
    this.service.postApi('/api/v1/adminUser/userDashboard', apiData, 1).subscribe((success) => {
      // console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        this.chartStatus = true

        this.totalUsers = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData = totalpercentage.toFixed(2)

        console.log("this.chartData==>", this.chartData)

        this.chartOptions = {
          series: [this.chartData],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // console.log("success==>",success)
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

    // ===================================Restaurnt Dashboard ============================================//

    this.service.postApi('/api/v1/adminUser/restaurntDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.totalRestaurnt = success.Data


        let totalpercentage = success.TotalPercentage

        this.chartData1 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage



        this.chartOptions1 = {
          series: [this.chartData1],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

    // ===================================Order Dashboard =================================================//

    this.service.postApi('/api/v1/adminUser/orderDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        let totalpercentage = success.TotalPercentage

        this.chartData2 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions2 = {
          series: [this.chartData2],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

    // =====================================Item Dashboard ==================================================//

    this.service.postApi('/api/v1/adminUser/itemDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.totalItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData5 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions5 = {
          series: [this.chartData5],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })




  }

  onCustomerStatus(event: any) {
    // this.selectedValue = value

    let apiData = {}

    // this.onTodayStatus = true
    // this.searchStatus = false
    // this.calanderStatus = false
    if (this.onTodayStatus == true) {
      apiData = {
        "timeframe": this.selectedValue,
        "status": event.target.value
      }
    }

    if (this.calanderStatus == true) {
      apiData = {
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
        "status": event.target.value
      }
    }


    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/userDashboard', apiData, 1).subscribe((success) => {
      // console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        this.chartStatus = true

        this.totalUsers = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData = totalpercentage.toFixed(2)

        console.log("this.chartData==>", this.chartData)

        this.chartOptions = {
          series: [this.chartData],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // console.log("success==>",success)
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRestaurntsStatus(event: any) {
    let apiData = {}

    // this.onTodayStatus = true
    // this.searchStatus = false
    // this.calanderStatus = false
    if (this.onTodayStatus == true) {
      apiData = {
        "timeframe": this.selectedValue,
        "status": event.target.value
      }
    }

    if (this.calanderStatus == true) {
      apiData = {
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
        "status": event.target.value
      }
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurntDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.totalRestaurnt = success.Data

        this.totalRestaurnt = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData1 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage



        this.chartOptions1 = {
          series: [this.chartData1],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onorderStatus(event: any) {
    let apiData = {}

    // this.onTodayStatus = true
    // this.searchStatus = false
    // this.calanderStatus = false
    if (this.onTodayStatus == true) {
      apiData = {
        "timeframe": this.selectedValue,
        "status": event.target.value
      }
    }

    if (this.calanderStatus == true) {
      apiData = {
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
        "status": event.target.value
      }
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/orderDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.totalOrder = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData2 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions2 = {
          series: [this.chartData2],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onItemStatus(event: any) {
    let apiData = {}

    // this.onTodayStatus = true
    // this.searchStatus = false
    // this.calanderStatus = false
    if (this.onTodayStatus == true) {
      apiData = {
        "timeframe": this.selectedValue,
        "status": event.target.value
      }
    }

    if (this.calanderStatus == true) {
      apiData = {
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
        "status": event.target.value
      }
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/itemDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.totalItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData5 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions5 = {
          series: [this.chartData5],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onfinanceStatus(event: any) {
    let apiData = {}

    // this.onTodayStatus = true
    // this.searchStatus = false
    // this.calanderStatus = false
    if (this.onTodayStatus == true) {
      apiData = {
        "timeframe": this.selectedValue,
        "status": event.target.value
      }
    }

    if (this.calanderStatus == true) {
      apiData = {
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
        "status": event.target.value
      }
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/financeDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.totalItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData7 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions7 = {
          series: [this.chartData7],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  creditStatus(event: any) {
    let apiData = {}

    // this.onTodayStatus = true
    // this.searchStatus = false
    // this.calanderStatus = false
    if (this.onTodayStatus == true) {
      apiData = {
        "timeframe": this.selectedValue,
        "status": event.target.value
      }
    }

    if (this.calanderStatus == true) {
      apiData = {
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
        "status": event.target.value
      }
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/creditDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.creditItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData10 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions4 = {
          series: [this.chartData10],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  rewardStatus(event: any) {
    let apiData = {}

    // this.onTodayStatus = true
    // this.searchStatus = false
    // this.calanderStatus = false
    if (this.onTodayStatus == true) {
      apiData = {
        "timeframe": this.selectedValue,
        "status": event.target.value
      }
    }

    if (this.calanderStatus == true) {
      apiData = {
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
        "status": event.target.value
      }
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/rewardDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.rewardItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData3 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions3 = {
          series: [this.chartData3],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  savedStatus(event: any) {
    let apiData = {}

    // this.onTodayStatus = true
    // this.searchStatus = false
    // this.calanderStatus = false
    if (this.onTodayStatus == true) {
      apiData = {
        "timeframe": this.selectedValue,
        "status": event.target.value
      }
    }

    if (this.calanderStatus == true) {
      apiData = {
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
        "status": event.target.value
      }
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/savedDashboard', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)

        this.savedItem = success.Data

        let totalpercentage = success.TotalPercentage

        this.chartData6 = totalpercentage.toFixed(2)

        // this.chartData1 = success.TotalPercentage

        this.chartOptions6 = {
          series: [this.chartData6],
          chart: {
            height: 120,
            type: "radialBar"
          },
          fill: {
            opacity: 1,
            colors: ['#85D8D9']
          },
          plotOptions: {
            radialBar: {
              hollow: {
                size: "50%"
              }
            }
          },

          // labels: ["Financial"]
        };
        // this.usersLists = success.data.docs
        // this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }




}
