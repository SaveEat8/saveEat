import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import * as xlsx from 'xlsx';
declare var $:any

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 10000;
  usersLists:any = []
  usersCount:any
  brandLists:any = []
  brandsCount:any
  brandId:any
  getBrandId:any
  restaurantId:any
  search:any = FormGroup;
  calanderSearch:any = FormGroup;
  subAdminEdit: any = FormGroup;
  formvalidation: any = { submitted: false }
  selectedValue :any = 'Today'

  roleList:any=[]
  onTodayStatus:any = true
  searchStatus:any = false
  calanderStatus:any = false 
  userId:any
  userRole:any

  viewCheck:any = false
  editCheck:any = false
  blockCheck:any = false
  deleteCheck:any = false
  addCheck:any = false

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {
      this.search = this.formBuilder.group({
        search: ['', [Validators.required]]
      });

      this.calanderSearch = this.formBuilder.group({
        startDate: ['', [Validators.required]],
        endDate: ['', [Validators.required]]
      });

      this.subAdminEdit = this.formBuilder.group({
        name: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/)]],
        mobileNumber: ['', [Validators.required]],
        // password: ['', [Validators.required,Validators.minLength(6), Validators.maxLength(16)]],
        role:['', [Validators.required]]
      });
     }

  ngOnInit(): void {
    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')
    this.deleteCheck = localStorage.getItem('Delete')
    this.addCheck = localStorage.getItem('Add')

    
    console.log("this.viewCheck==>",this.viewCheck)
    console.log("this.viewCheck==>",this.editCheck)
        // this.onRestaurantsLists()
        this.onToday('Month')
        this.onRoleList()
        // localStorage.removeItem("Id");
        // localStorage.removeItem("storeId");
  }

  onUsersLists(){

    let apiData = {
      pageNumber:this.p

    }
    // userNumber
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/subAdminList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onUsersListsPagination(event:any){
    this.p = event
    let apiData
    // this.onTodayStatus = false
    // this.searchStatus = false
    // this.calanderStatus = false 

    if(this.onTodayStatus == true){
       apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "timeframe": this.selectedValue,
      }
    }

    if(this.searchStatus == true){
      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
      }
    }

    if(this.calanderStatus == true){

      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }



    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/subAdminList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
              // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch(){

    this.p = 1
    this.formvalidation.submitted = true
    if (this.search.invalid) {
      this.onToday(this.selectedValue)
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus = false
    this.searchStatus = true
    this.calanderStatus = false 

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "search": this.search.value.search,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/subAdminList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  exportToExcel() {
    const ws: xlsx.WorkSheet =
    xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'userList.xlsx');
  }

  onCalenderSearch(){
    this.p = 1
    this.formvalidation.submitted = true

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true 

    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/subAdminList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total

        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(value:any){
    this.selectedValue = value
    this.p = 1

    this.onTodayStatus = true
    this.searchStatus = false
    this.calanderStatus = false 

    let apiData = {
      pageNumber:this.p,
      limit:this.itemPerPage,
      "timeframe": value,
    }

    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/subAdminList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data.docs
        this.usersCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetUserId(id:any){
    this.userId = id
  }

  onActiveStatus(){

    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }


    let apiData = {
      adminId: this.userId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/subAdminStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()
        this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      adminId: this.userId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/subAdminStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSubadminDetail(id:any){
    this.userId = id

    let apiData = {
      "adminId": this.userId,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/particularSubAdmin', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        console.log("success---->",success)
        this.service.hideSpinner()
        this.userRole = success.data
        this.subAdminEdit.controls['name'].setValue(success.data.name);
        this.subAdminEdit.controls['email'].setValue(success.data.email);
        this.subAdminEdit.controls['mobileNumber'].setValue(success.data.mobileNumber);
        // this.subAdminEdit.controls['password'].setValue(success.Data.password);
        // this.subAdminEdit.controls['role'].setValue(success.data.role);


      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

  onEditSubadmin(cuisinData: any) {

    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.formvalidation.submitted = true
    if (this.subAdminEdit.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }

    let apiData = {
      "adminId": this.userId,
      "name": cuisinData.name,
      "password": cuisinData.password,
      "mobileNumber": cuisinData.mobileNumber,
      "email": cuisinData.email,
      "role": cuisinData.role
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/subAdminUpdate', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        this.subAdminEdit.reset()
        this.service.succ("updated")
         $("#edit").modal("hide");
        this.onToday(this.selectedValue)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

  onDeleteSubAdmin(){
    if(this.deleteCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {
      "adminId": this.userId,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/deleteSubAdmin', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        this.subAdminEdit.reset()
        // this.service.succ("updated")
         $("#delete").modal("hide");
        this.onToday(this.selectedValue)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRoleList() {

    let apiData = {
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminAllRoleList', apiData, 1).subscribe((success) => {
      console.log("success",success)
      if (success.status == 200) {
        this.service.hideSpinner()

        this.roleList = success.data
        
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

  onUserCheck(){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/role-managemnt'])

  }

  onAddUser(){
    if(this.addCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/add-users'])
    
  }

}
