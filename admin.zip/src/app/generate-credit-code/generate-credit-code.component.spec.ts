import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateCreditCodeComponent } from './generate-credit-code.component';

describe('GenerateCreditCodeComponent', () => {
  let component: GenerateCreditCodeComponent;
  let fixture: ComponentFixture<GenerateCreditCodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenerateCreditCodeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateCreditCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
