import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { DatePipe } from '@angular/common';


declare var $:any

@Component({
  selector: 'app-generate-credit-code',
  templateUrl: './generate-credit-code.component.html',
  styleUrls: ['./generate-credit-code.component.css']
})
export class GenerateCreditCodeComponent implements OnInit {

  formvalidation: any = { submitted: false }
  createCoin: any = FormGroup;
  searchUser: any = FormGroup;


  todayDate:any
  todayDate1:any


  roleList: any = []
  userIdArr: any = []
  userList:any = []

  checkMe:any = false

  addCheck:any = false


  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe) {
    this.createCoin = this.formBuilder.group({
      creditTitle: ['',[Validators.required]],
      creditCode: ['',[Validators.required]],
      creditType: [''],
      totalFrequency: ['',[Validators.required]],
      creditAmount: ['',[Validators.required]],
      fromDate: ['',[Validators.required]],
      toDate: ['',[Validators.required]],
      description:['',[Validators.required]]
    });

    this.searchUser = this.formBuilder.group({
      search: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.addCheck = localStorage.getItem('Add')

    // Active();
    var date = new Date();
    var date1 = new Date();
    date1.setDate(date1.getDate() + 1);

    this.todayDate = this.datePipe.transform(date, "yyyy-MM-dd");

    this.todayDate1 = this.datePipe.transform(date1, "yyyy-MM-dd");

  }

  onSelectUser(id: any) {

    if(this.checkMe == true){
      return this.service.err("Please uncheck Upload for All Customers!")
    }


    if(id.target.value != ''){

      let index = this.userIdArr.findIndex((x:any) => x === id.target.value);
      if (index > -1) {
        // this.userIdArr[index]
        // this.userIdArr.splice(index, 1);
      } else {
        this.userIdArr.push(id.target.value)
      }
      // this.userIdArr.push(id.target.value)
      console.log("this.userIdArr==>",this.userIdArr)
    }

  }

  onRemoveUser(id:any){
    console.log("id==>",id)
    let selectedUser =  this.userIdArr[id]
    console.log("selectedUser",selectedUser)
    let index = this.userIdArr.findIndex((x:any) => x === selectedUser);
    if (index > -1) {
      this.userIdArr[index]
      this.userIdArr.splice(index, 1);
    } else {
      // this.userIdArr.push(selectedUser)
    }
  }

  onSelectAll(){

    if(this.userIdArr.length > 0){
      this.userIdArr = []

      // this.checkMe = false
      // return this.service.err("Please remove selected user!")
    }


    if(this.checkMe == false){
      this.checkMe = true
    }else{
      this.checkMe = false
      this.userIdArr = []
    }

  }

  onSearchUser(){
    this.formvalidation.submitted = true
    // if (this.searchUser.invalid) {
    //   return
    // }
    let search =  $('#address1').val() 


    let apiData = {
      "search": search
    }

    console.log("apiData===>", apiData)

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onSearchUser', apiData, 0).subscribe((success) => {
      // console.log("success===>",success)
      if (success.status == 200) {
        this.service.hideSpinner()
        this.userList = success.data
        console.log("this.userList===>",this.userList)
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCreateCoin() {

    if(this.addCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.formvalidation.submitted = true
    if (this.createCoin.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }

    let apiData: any = {}

    // if (this.userIdArr.length > 0) {
    //   apiData.userId = this.userIdArr
    // }else{
    //   apiData.allCustomers = "true"
    // }

    if (this.createCoin.value.creditTitle) {
      apiData.creditTitle = this.createCoin.value.creditTitle
    }

    if (this.createCoin.value.creditCode) {
      apiData.creditCode = this.createCoin.value.creditCode
    }

    // if (this.createCoin.value.creditType) {
    //   apiData.creditType = this.createCoin.value.creditType
    // }

    if (this.createCoin.value.totalFrequency) {
      apiData.totalFrequency = this.createCoin.value.totalFrequency
    }

    if (this.createCoin.value.creditAmount) {
      if (this.createCoin.value.creditAmount > 500) {
        return this.service.err("Max amount is 500")
      }
      apiData.creditAmount = this.createCoin.value.creditAmount
    }

    if (this.createCoin.value.fromDate) {
      apiData.fromDate = this.createCoin.value.fromDate
    }

    if (this.createCoin.value.toDate) {
      apiData.toDate = this.createCoin.value.toDate
    }

    if (this.createCoin.value.description) {
      apiData.description = this.createCoin.value.description
    }

    apiData.creditType = "Code"

    console.log("apiData===>", apiData)

    
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreateCoin', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        this.createCoin.reset()
        this.service.succ(success.message)
        this.route.navigate(['/generated-credit-code-list'])
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

}
