import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import * as xlsx from 'xlsx';
declare var $: any

@Component({
  selector: 'app-role-managemnt',
  templateUrl: './role-managemnt.component.html',
  styleUrls: ['./role-managemnt.component.css']
})
export class RoleManagemntComponent implements OnInit {
  p: any = 1;
  p1: any = 1;
  srNo: any;
  total: any = Number;
  pages: any;
  itemPerPage: any = 10000;
  restaurantsLists: any = []
  restaurantsCount: any
  brandLists: any = []
  brandsCount: any
  brandId: any
  getBrandId: any
  restaurantId: any
  search: any = FormGroup;
  calanderSearch: any = FormGroup;
  formvalidation: any = { submitted: false }
  selectedValue: any = 'Today'
  profilePic: any = localStorage.getItem("profilePic")

  restrauntId:any
  restaurantData:any = []
  roleId:any


  onTodayStatus: any = true
  searchStatus: any = false
  calanderStatus: any = false

  viewCheck:any = false
  editCheck:any = false
  blockCheck:any = false
  deleteCheck:any = false
  addCheck:any = false

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {
    this.search = this.formBuilder.group({
      search: ['', [Validators.required]]
    });

    this.calanderSearch = this.formBuilder.group({
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')
    this.deleteCheck = localStorage.getItem('Delete')
    this.addCheck = localStorage.getItem('Add')

    localStorage.removeItem("restorentId");
    localStorage.removeItem("storeId");
    this.onToday('Today')

  }

  onRestaurantsLists() {

    let apiData = {
      pageNumber: this.p

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminRoleList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.restaurantsLists = success.data.docs
        this.restaurantsCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRestaurantsListsPagination(event: any) {
    this.p = event
    // let apiData = {
    //   pageNumber:this.p

    // }
    let apiData

    if (this.onTodayStatus == true) {
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "timeframe": this.selectedValue,
      }
    }

    if (this.searchStatus == true) {
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
      }
    }

    if (this.calanderStatus == true) {

      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }


    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminRoleList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.restaurantsLists = success.data.docs
        this.restaurantsCount = success.data.total        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch() {
    this.p = 1
    this.formvalidation.submitted = true
    if (this.search.invalid) {
      this.onToday(this.selectedValue)
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus = false
    this.searchStatus = true
    this.calanderStatus = false

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "search": this.search.value.search,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminRoleList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.restaurantsLists = success.data.docs
        this.restaurantsCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }




  onCalenderSearch() {
    this.p = 1
    this.formvalidation.submitted = true
    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true

    //   let startDate =  new Date(this.calanderSearch.value.startDate);
    //   let endDate = new Date(this.calanderSearch.value.endDate);

    //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
    //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


    //   let startDates = new Date(updatedStartDate)
    //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminRoleList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.restaurantsLists = success.data.docs
        this.restaurantsCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(value: any) {
    this.selectedValue = value
    this.p = 1

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "timeframe": value,
    }

    this.onTodayStatus = true
    this.searchStatus = false
    this.calanderStatus = false

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminRoleList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.restaurantsLists = success.data.docs
        this.restaurantsCount = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetRestrauntId(id:any){
    this.restrauntId = id
    let apiData = {
      orderId:id
    }
    console.log("data",apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/admin/adminRoleList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)
      if (success.response_code == 200) {
        console.log("success==>",success)
        this.restaurantData = success.Data[0]
        console.log("this.restaurantData==>",this.restaurantData)
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetRoleId(id:any){
    this.roleId = id
  }

  onActiveStatus(){

    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {
      roleId: this.roleId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/updateRoleStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()
        this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus(){

    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {
      roleId: this.roleId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/updateRoleStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDeleteRole(){
    if(this.deleteCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      roleId: this.roleId,
      deleteStatus: true
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/deleteRole', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        this.onToday(this.selectedValue)
        $("#trash").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  onAddRole(){
    if(this.addCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    // 

    this.route.navigate(['/users'])
  }


}
