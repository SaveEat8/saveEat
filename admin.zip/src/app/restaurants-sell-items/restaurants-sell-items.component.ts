import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../app.service';

@Component({
  selector: 'app-restaurants-sell-items',
  templateUrl: './restaurants-sell-items.component.html',
  styleUrls: ['./restaurants-sell-items.component.css']
})
export class RestaurantsSellItemsComponent implements OnInit {

  fetchId:any
  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 10;
  sellItemList:any = []
  sellItemCount:any
  menuId:any
  getBrandId:any
  restaurantId:any
  profilePic:any=localStorage.getItem("profilePic")
  productId:any


  viewCheck:any = false
  editCheck:any = false
  blockCheck:any = false
  deleteCheck:any = false
  addCheck:any = false

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')
    this.deleteCheck = localStorage.getItem('Delete')
    this.addCheck = localStorage.getItem('Add')
    this.onFetchId()
    this.onMenuLists()
  }

  onFetchId(){
    this.fetchId = localStorage.getItem("restorentId")
  }

  onMenuLists(){

    let apiData = {
      brandId:localStorage.getItem("restorentId"),
      pageNumber:this.p

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/sellItemsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.sellItemList = success.Data
        this.sellItemCount = success.TotalCount
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }
  
  onMenuListsPagination(event:any){
    this.p = event
    let apiData = {
      brandId:localStorage.getItem("restorentId"),
      pageNumber:this.p

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/sellItemsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.sellItemList = success.Data
        this.sellItemCount = success.TotalCount
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetId(id:any){
    this.productId =id
    console.log("this.productId",this.productId)
  }

  onActiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      brandId: this.productId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateSellproduct', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()
        this.onMenuLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      brandId: this.productId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateSellproduct', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        this.onMenuLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

}
