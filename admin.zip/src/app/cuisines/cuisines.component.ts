import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';

declare var $: any;

@Component({
  selector: 'app-cuisines',
  templateUrl: './cuisines.component.html',
  styleUrls: ['./cuisines.component.css']
})
export class CuisinesComponent implements OnInit {

  p: any = 1;
  p1: any = 1;
  srNo: any;
  total: any = Number;
  pages: any;
  itemPerPage: any = 50;
  cuisines: any
  cusinesLists: any = []
  cusinesCounts: any
  brandLists: any = []
  particularCuisines: any = []
  brandsCount: any
  brandId: any
  cuisinesId: any
  formvalidation: any = { submitted: false }
  cuisinesCreate: any = FormGroup;
  cuisinesEdit: any = FormGroup;

  subCusinesLists: any = []
  subCusinesCounts: any

  subcuisinesCreate: any = FormGroup;
  subcuisinesEdit: any = FormGroup;
  search:any = FormGroup;

  subCuisinesId:any
  calanderSearch:any
  profilePic:any=localStorage.getItem("profilePic")

  viewCheck:any = false
  editCheck:any = false
  blockCheck:any = false
  deleteCheck:any = false
  addCheck:any = false

  constructor(private route: Router,
    private formBuilder: FormBuilder,
    private service: AppService,
    private activatedRoute: ActivatedRoute) {
    this.cuisinesCreate = this.formBuilder.group({
      name: ['', [Validators.required]]
    });

    this.cuisinesEdit = this.formBuilder.group({
      name: ['', [Validators.required]]
    });

    this.subcuisinesCreate = this.formBuilder.group({
      name: ['', [Validators.required]]
    });

    this.subcuisinesEdit = this.formBuilder.group({
      name: ['', [Validators.required]]
    });

    
    this.search = this.formBuilder.group({
      search: ['', [Validators.required]]
    });

    this.calanderSearch = this.formBuilder.group({
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')
    this.deleteCheck = localStorage.getItem('Delete')
    this.addCheck = localStorage.getItem('Add')
    this.onCuisinesLists()
  }

  onCuisinesLists() {

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineListAggergation', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        console.log("success==>", success)
        this.service.hideSpinner()
        this.cusinesLists = success.data
        this.cusinesCounts = success.total
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  oncuisinesListPageChange(event: any) {
    this.p = event

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineListAggergation', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        console.log("success==>", success)
        this.cusinesLists = success.data
        this.cusinesCounts = success.total
        this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch(){
    this.p = 1
    this.formvalidation.submitted = true
    if (this.search.invalid) {
      this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "search": this.search.value.search,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineListAggergation', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        console.log("success==>", success)
        this.service.hideSpinner()
        this.cusinesLists = success.data
        this.cusinesCounts = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCalenderSearch(){
    // this.p = 1
    this.formvalidation.submitted = true
    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("apidate",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineListAggergation', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        console.log("success==>", success)
                this.service.hideSpinner()
        this.cusinesLists = success.data
        this.cusinesCounts = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }
  

  onParticularCuisinesData(id: any) {
    this.cuisinesId = id

    let apiData = {
      cuisineId: id,

    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/particularCuisine', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        console.log("success==>", success.Data.name)
        // this.brandLists = success.Data
        this.cuisinesEdit.controls['name'].setValue(success.Data.name);

        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCreateCuisines(cuisinData: any) {
    if(this.addCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    this.formvalidation.submitted = true
    if (this.cuisinesCreate.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }

    let apiData = {
      "name": cuisinData.name,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/addCuisine', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        $("#Cuisines").modal("hide");
        this.cuisinesCreate.reset()
        this.service.succ(success.message)
        this.onCuisinesLists()
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

  onUpdateCuisines(cuisinData: any) {
    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    this.formvalidation.submitted = true
    if (this.cuisinesEdit.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }
    let apiData = {
      cuisineId: this.cuisinesId,
      name: cuisinData.name

    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/updateCuisine', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        // console.log("success==>",success.Data.name)
        // this.brandLists = success.Data

        // this.service.hideSpinner()
        $("#Edit_Cuisines").modal("hide");
        this.cuisinesEdit.reset()
        this.service.succ(success.message)
        this.onCuisinesLists()

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDeleteCuisinesId(id: any) {
    this.cuisinesId = id
  }

  onDeleteCuisines() {
    if(this.deleteCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      cuisineId: this.cuisinesId,
    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/deleteCuisine', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        $("#delete").modal("hide");
        this.onCuisinesLists()

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }



  onSubCuisines(id: any) {
    this.cuisinesId = id

    let apiData = {
      cuisineId: id,
      pageNumber: this.p1,
      limit: this.itemPerPage
    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineSubCategoryList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        console.log("success==>", success)
        this.subCusinesLists = success.data.docs
        this.subCusinesCounts = success.total
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSubCuisinesPagination(event: any) {
    this.p1 = event

    let apiData = {
      cuisineId: this.cuisinesId,
      pageNumber: this.p1,
      limit: this.itemPerPage
    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineSubCategoryList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        console.log("success==>", success)
        this.subCusinesLists = success.data.docs
        this.subCusinesCounts = success.total
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onParticularSubCuisinesData(id: any) {
    this.subCuisinesId = id

    let apiData = {
      cuisineCategoryId: id,

    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/particularSubCuisine', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        console.log("success==>", success.Data.name)
        // this.brandLists = success.Data
        this.subcuisinesEdit.controls['name'].setValue(success.Data.name);

        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCreateSubCuisines(cuisinData: any) {
    this.formvalidation.submitted = true
    if (this.subcuisinesCreate.invalid) {
      this.service.err("Please enter cuisin name!")
      return
    }

    let apiData = {
      "name": cuisinData.name,
      "cuisineId":  this.cuisinesId
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/addCuisineCategory', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        $("#SubCuisines").modal("hide");
        this.subcuisinesCreate.reset()
        this.service.succ(success.message)
        this.onSubCuisines( this.cuisinesId)
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

  onUpdateSubCuisines(cuisinData: any) {
    this.formvalidation.submitted = true
    if (this.subcuisinesEdit.invalid) {
      this.service.err("Please enter cuisin name!")
      return
    }
    let apiData = {
      cuisineCategoryId: this.subCuisinesId,
      name: cuisinData.name

    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/updateCuisineCategory', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        // console.log("success==>",success.Data.name)
        // this.brandLists = success.Data

        // this.service.hideSpinner()
        $("#Edit_SubCuisines").modal("hide");
        this.subcuisinesEdit.reset()
        this.service.succ(success.message)
        this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDeleteSubCuisinesId(id: any) {
    this.subCuisinesId = id
  }

  onDeleteSubCuisines() {
    let apiData = {
      cuisineCategoryId: this.subCuisinesId,
    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/deleteCuisineCategory', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        $("#Subdelete").modal("hide");
        this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRefresh(){
    window.location.reload();
  }


  onShowSubCuisins(id:any){
    if(this.addCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/sub-cuisines',id])
  }

}
