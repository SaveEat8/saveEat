import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCreditHistoryComponent } from './user-credit-history.component';

describe('UserCreditHistoryComponent', () => {
  let component: UserCreditHistoryComponent;
  let fixture: ComponentFixture<UserCreditHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserCreditHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCreditHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
