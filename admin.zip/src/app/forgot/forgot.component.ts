import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {

  formvalidation: any = { submitted: false }
  forgotForm:any= FormGroup
  constructor(
    private route: Router,
    private service: AppService,
    private cookieService: CookieService
  ) { }

  ngOnInit(): void {

    this.forgotForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/)]),
     
    });
  }

  forgotFunction(data:any) {

    this.formvalidation.submitted = true
    if (this.forgotForm.invalid) {
      return
    }
    let apiData = {
      "email": data.email,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminForgotPassword', apiData, 0).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        localStorage.setItem("email",data.email)
        this.route.navigate(['/otp'])
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

}
