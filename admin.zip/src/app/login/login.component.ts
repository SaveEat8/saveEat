import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { CookieService } from 'ngx-cookie-service';
import { HttpClient } from '@angular/common/http';
declare function password():any;


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  formvalidation: any = { submitted: false }
  loginForm:any= FormGroup
  loginStatus:boolean=false
  adminEmail:any
  adminPassword:any
  constructor(
    private route: Router,
    private service: AppService,
    private cookieService: CookieService,
    private activatedRoute: ActivatedRoute,
    private http: HttpClient
  ) { }

  ngOnInit(): void {
     password()
     this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/)]),
      password: new FormControl('', [Validators.required,Validators.minLength(6), Validators.maxLength(16)]),
    });
  }

  loginFunction(loginData:any) {

    this.formvalidation.submitted = true
    if (this.loginForm.invalid) {
      this.service.err("Please enter email & password!")
      return
    }
    let apiData = {
      "email": loginData.email,
      "password": loginData.password
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminLogin', apiData, 0).subscribe((success) => {
      if (success.status == 200) {
        console.log("success===>",success)
        this.service.hideSpinner()
        this.loginForm.reset()
        this.service.succ(success.message)
        this.route.navigate(['/dashborad'])
        localStorage.setItem("superId",success.data._id)
        localStorage.setItem("name",success.data.name)
        localStorage.setItem("profilePic",success.data.profilePic)
        localStorage.setItem("userType",success.data.userType)
        localStorage.setItem('Role', JSON.stringify(success.Role));


      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

}
