import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
declare var $:any


@Component({
  selector: 'app-creadit-given',
  templateUrl: './creadit-given.component.html',
  styleUrls: ['./creadit-given.component.css']
})
export class CreaditGivenComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 50;
  usersLists:any = []
  usersCount:any
  brandLists:any = []
  brandsCount:any
  brandId:any
  getBrandId:any
  restaurantId:any
  search:any = FormGroup;
  calanderSearch:any = FormGroup;
  formvalidation: any = { submitted: false }
  selectedValue :any = 'Today'

  onTodayStatus:any = true
  searchStatus:any = false
  calanderStatus:any = false 
  userId:any



  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {

      this.search = this.formBuilder.group({
        search: ['', [Validators.required]]
      });

      this.calanderSearch = this.formBuilder.group({
        startDate: ['', [Validators.required]],
        endDate: ['', [Validators.required]]
      });
      
     }


  ngOnInit(): void {
       localStorage.removeItem("coustmerId");
        // this.onRestaurantsLists()
        this.onToday()
        // localStorage.removeItem("Id");
        // localStorage.removeItem("storeId");
  }

  onUsersLists(){

    let apiData = {
      pageNumber:this.p,
      creditType:"Direct"
    }
    // userNumber
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onUsersListsPagination(event:any){
    this.p = event
    let apiData
    // this.onTodayStatus = false
    // this.searchStatus = false
    // this.calanderStatus = false 

    if(this.onTodayStatus == true){
       apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        // "timeframe": this.selectedValue,
      }
    }

    if(this.searchStatus == true){
      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        creditType:"Direct",
        "search": this.search.value.search,
      }
    }

    if(this.calanderStatus == true){

      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "startDate": new Date(this.calanderSearch.value.startDate),
        creditType:"Direct",
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }



    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
              // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch(){

    this.p = 1
    this.formvalidation.submitted = true
    if (this.search.invalid) {
      this.onToday()
      // this.service.err("Please enter cuisin name!")
      return
    }


    let apiData = {
      
    }

    // this.onTodayStatus = false
    // this.searchStatus = true
    // this.calanderStatus = false 

    if(this.calanderStatus == true){
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        creditType:"Direct",
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }

    if(this.onTodayStatus ==true){
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        creditType:"Direct"
        // "timeframe": this.selectedValue,

      }
    }


    console.log("apiData==>",apiData)

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }



  onCalenderSearch(){
    this.p = 1
    this.formvalidation.submitted = true

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true 

    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
      creditType:"Direct"

    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total

        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(){
    this.p = 1


    this.searchStatus = false
    this.calanderStatus = false 

    let apiData = {
      pageNumber:this.p,
      limit:this.itemPerPage,
      creditType:"Direct"

      // "timeframe": value,
    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetUserId(id:any){
    this.userId = id
  }

  onActiveStatus(){
    let apiData = {
      userId: this.userId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateUserStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()
        this.onToday()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus(){
    let apiData = {
      userId: this.userId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateUserStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        this.onToday()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

}
