import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import * as xlsx from 'xlsx';
declare var $:any

@Component({
  selector: 'app-restaurants',
  templateUrl: './restaurants.component.html',
  styleUrls: ['./restaurants.component.css']
})
export class RestaurantsComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  @ViewChild('epltable1', { static: false }) epltable1: ElementRef;



  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 10;
  restaurantsLists:any = []
  restaurantsCount:any
  brandLists:any = []
  brandsCount:any
  brandId:any
  getBrandId:any
  restaurantId:any
  search:any = FormGroup;
  calanderSearch:any = FormGroup;
  commissionForm:any = FormGroup;
  walletForm:any = FormGroup;
  particularRestaurnet:any
  amount:any

  submitted = false
  formInvalid = false

  formvalidation: any = { submitted: false }
  selectedValue :any 
  profilePic:any=localStorage.getItem("profilePic")
  

  onTodayStatus:any = true
  searchStatus:any = false
  calanderStatus:any = false 

  onshowAll:any = true

  viewCheck:any = false
  editCheck:any = false
  blockCheck:any = false

  adminType= localStorage.getItem('userType');


  constructor(  private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder
    ) {
      this.search = this.formBuilder.group({
        search: ['', [Validators.required]]
      });

      this.calanderSearch = this.formBuilder.group({
        startDate: ['', [Validators.required]],
        endDate: ['', [Validators.required]]
      });

      this.commissionForm = this.formBuilder.group({
        tax: ['', [Validators.required]],
        commission: ['', [Validators.required]]
      });
      this.walletForm = this.formBuilder.group({
        wallet: ['']
      });
      
     }

  ngOnInit(): void {

    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')

    console.log("this.viewCheck==>",this.viewCheck)
    console.log("this.editCheck==>",this.editCheck)

    localStorage.removeItem("restorentId");
    localStorage.removeItem("storeId");
    // this.onRestaurantsLists()
    this.onFullPrice()
    // this.onToday('Today')


  }

  onRestaurantsLists(){

    let apiData = {
      pageNumber:this.p

    }

    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurantsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.Data
        this.restaurantsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRestaurantsListsPagination(event:any){
    this.p = event
    // let apiData = {
    //   pageNumber:this.p

    // }
    let apiData 

    this.onshowAll = false
    if(this.onTodayStatus == true){
      apiData = {
       pageNumber:this.p,
       limit: this.itemPerPage,
       "timeframe": this.selectedValue,
     }
   }

   if(this.searchStatus == true){
     apiData = {
       pageNumber:this.p,
       limit: this.itemPerPage,
       "search": this.search.value.search,
     }
   }

   if(this.calanderStatus == true){

     apiData = {
       pageNumber:this.p,
       limit: this.itemPerPage,
       "startDate": new Date(this.calanderSearch.value.startDate),
       "endDate": new Date(this.calanderSearch.value.endDate),
     }

   }


    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurantsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.Data
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch(){
    this.p = 1
    this.formvalidation.submitted = true
    // if (this.search.invalid) {
    //   // this.onToday(this.selectedValue)
    //   // this.onFullPrice()

    //   // this.service.err("Please enter cuisin name!")
    //   return
    // }

    // this.onTodayStatus = false
    this.searchStatus = true
    // this.calanderStatus = false 
    // this.onshowAll = false
    let apiData

    if(this.onTodayStatus == true){

       apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "timeframe": this.selectedValue,
        "search": this.search.value.search,
      }
    }

    if(this.calanderStatus == true){
       apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        "timeframe": this.selectedValue,
      }
    }

    if(this.onshowAll == true){
       apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        "fullPrice": "fullPrice",
      }
    }


    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurantsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.Data
        this.restaurantsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onBrandLists(id:any){

    this.brandId = id

    let apiData = {
      brandId: id,
      pageNumber:this.p1,
      limit: this.itemPerPage,
    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restrauntBrandList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.brandLists = success.Data
        this.brandsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

  onBrandListsPageChange(event:any){

    this.p1 = event
    let apiData = {
      brandId: this.brandId,
      pageNumber:this.p1,
      limit: this.itemPerPage,


    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restrauntBrandList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
          this.service.hideSpinner()
        console.log("success==>",success)
        this.brandLists = success.Data
        this.brandsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

  onGetRestaurntId(id:any){
    this.restaurantId = id
  }
  

  exportToExcel() {
    // const ws: xlsx.WorkSheet =
    // xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    // const wb: xlsx.WorkBook = xlsx.utils.book_new();
    // xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    // xlsx.writeFile(wb, 'restaurantList.xlsx');

    let apiData 
    // this.onTodayStatus = false

    if(this.onTodayStatus == true){
      apiData = {
       "timeframe": this.selectedValue,
     }
   }

   if(this.calanderStatus == true){
    apiData = {
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }
  }

  if(this.searchStatus == true){
    apiData = {
      "search": this.search.value.search,
    }
  }

//   if(this.onshowAll == true){
//     apiData = {
//      "search": this.search.value.search,
//      "fullPrice": "fullPrice",
//    }
//  }
console.log("apiData==>",apiData)

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurantsDownloadList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("linkk==>",success.data)
        window.open(success.data, '_blank');
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  onApproveRestaurants(){
    let apiData = {
      brandId: this.restaurantId,
      status: "Approve"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/approveRestaurnt', apiData, 1).subscribe((success) => {
      console.log("success==>", success)
      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDisApproveRestaurants(){
    let apiData = {
      brandId: this.restaurantId,
      status: "Disapprov"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/approveRestaurnt', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onActiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      brandId: this.restaurantId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateRestaurntStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()
        this.onFullPrice()

        // this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onAddWallet(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    console.log("data========================>", this.walletForm)

    let apiData = {
      
      amount: this.walletForm.value.wallet,
      brandId: this.getBrandId,
    }
    console.log("data========================>", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateRestaurntWallet', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        $("#WalletAmount").modal('hide')
        this.service.hideSpinner()
        this.walletForm.reset({wallet :['']})
        this.onFullPrice()
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      brandId: this.restaurantId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateRestaurntStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        this.onFullPrice()
        // this.onToday(this.selectedValue)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onBrandId(id:any){
    this.getBrandId = id
  }

  onActiveStoreStatus(){
    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      brandId: this.getBrandId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateBrandsStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()

        $("#ActiveBrunch").modal("hide");

        // this.onRestaurantsLists()
        this.onBrandLists(this.brandId)
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStoreStatus(){
    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      brandId: this.getBrandId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateBrandsStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        $("#InactiveBrunch").modal("hide");

        this.onBrandLists(this.brandId)
        // this.onRestaurantsLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  exportToExcel1() {
    const ws: xlsx.WorkSheet =
    xlsx.utils.table_to_sheet(this.epltable1.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'storeList.xlsx');
  }

  onCalenderSearch(){
    this.p = 1
    this.formvalidation.submitted = true
    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true 
    this.onshowAll = false

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurantsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.Data
        this.restaurantsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(value:any){
    this.selectedValue = value
    this.p = 1

    let apiData = {
      pageNumber:this.p,
      limit: this.itemPerPage,
      "timeframe": value,
    }

    this.onTodayStatus = true
    this.searchStatus = false
    this.calanderStatus = false 

    this.onshowAll = false

    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurantsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.Data
        this.restaurantsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onFullPrice(){
    this.p = 1

    let apiData = {
      pageNumber:this.p,
      limit: this.itemPerPage,
      "fullPrice": "fullPrice",
    }

    this.onTodayStatus = true
    this.searchStatus = false
    this.calanderStatus = false 

    this.onshowAll = true

    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/restaurantsList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.restaurantsLists = success.Data
        this.restaurantsCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onBrandCommissionId(id:any){
    this.getBrandId = id
    this.onRestaurnentDetails()
  }

  onWalletId(restaurants:any){
    this.getBrandId =restaurants._id
    console.log('=========>>>>restaurants',restaurants)
this.walletForm.controls['wallet'].setValue(restaurants.wallet)
    this.onRestaurnentDetails()
  }

  onRestaurnentDetails(){

    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {

      "restaurntId": this.getBrandId,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/particularRestaurnt', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.particularRestaurnet = success.Data

        this.commissionForm.controls['tax'].setValue(success.Data.fixCommissionPer);
        this.commissionForm.controls['commission'].setValue(success.Data.commission);


      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRestaurentCommissionUpdate(){

    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.formvalidation.submitted = true
    if (this.commissionForm.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }



    let apiData = {
      fixCommissionPer: this.commissionForm.value.tax,
      commission: this.commissionForm.value.commission,
      "brandId": this.getBrandId,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateRestaurntCommission', apiData, 1).subscribe((success) => {
      // console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
                this.service.succ(success.message)

                this.onFullPrice()
                $("#info").modal("hide");
        // console.log("success==>",success)
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  onShowHiddenCode(){
console.log(this.editCheck)
    if(this.editCheck == 'false'){
      console.log(this.editCheck)
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {
      brandId: this.restaurantId,
      hiddenStatus: true
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateRestaurntHiddenStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)

        this.service.postApi('/api/v1/adminUser/generateCodeHidden', apiData, 1).subscribe((success) => {
          console.log("success==>", success)
    
          if (success.status == 200) {
            this.service.succ(success.message)
            this.onFullPrice()

            // this.service.hideSpinner()
            // this.onToday(this.selectedValue)
            // $("#HiddenShow").modal("hide");
            // this.onSubCuisines( this.cuisinesId)
    
          }
          else {
            this.service.hideSpinner()
            this.service.err(success.message)
          }
        }, error => {
          this.service.hideSpinner()
        })


        this.service.hideSpinner()
        this.onToday(this.selectedValue)
        $("#Hidden").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onHideHiddenCode(){

    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {
      brandId: this.restaurantId,
      hiddenStatus: false
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateRestaurntHiddenStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()
        this.onFullPrice()
        $("#HiddenShow").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetRestaurentId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/restaurants-personal-information',id])
  }

  onGetWalletList(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/wallet-history',id])
  }

  onGetStroeId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/store-personal-info',id])
  }

  login(x:any){
    console.log('iddd---------------->',x)
    window.open(`https://business.saveeat.in/#/login/${x}`,"_blank")
  }



}
