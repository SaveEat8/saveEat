import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateCreditCodeGivenComponent } from './generate-credit-code-given.component';

describe('GenerateCreditCodeGivenComponent', () => {
  let component: GenerateCreditCodeGivenComponent;
  let fixture: ComponentFixture<GenerateCreditCodeGivenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenerateCreditCodeGivenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateCreditCodeGivenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
