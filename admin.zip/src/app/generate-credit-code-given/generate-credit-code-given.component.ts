import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { DatePipe } from '@angular/common';

declare var $:any

@Component({
  selector: 'app-generate-credit-code-given',
  templateUrl: './generate-credit-code-given.component.html',
  styleUrls: ['./generate-credit-code-given.component.css']
})
export class GenerateCreditCodeGivenComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 50;
  usersLists:any = []
  usersCount:any
  brandLists:any = []
  brandsCount:any
  brandId:any
  getBrandId:any
  restaurantId:any
  search:any = FormGroup;
  calanderSearch:any = FormGroup;
  formvalidation: any = { submitted: false }
  selectedValue :any = 'Today'

  onTodayStatus:any = true
  searchStatus:any = false
  calanderStatus:any = false 
  userId:any

  viewCheck:any = false
  createCoin: any = FormGroup;

  todayDate:any
  todayDate1:any

  editCheck:any = false
  blockCheck:any = false

  couponId:any
  couponDetails:any 

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe) {
      this.createCoin = this.formBuilder.group({
        creditTitle: ['',[Validators.required]],
        creditCode: ['',[Validators.required]],
        creditType: [''],
        totalFrequency: ['',[Validators.required]],
        creditAmount: ['',[Validators.required]],
        fromDate: ['',[Validators.required]],
        toDate: ['',[Validators.required]],
        description:['',[Validators.required]]
      });

      this.search = this.formBuilder.group({
        search: ['', [Validators.required]]
      });

      this.calanderSearch = this.formBuilder.group({
        startDate: ['', [Validators.required]],
        endDate: ['', [Validators.required]]
      });
      
     }


  ngOnInit(): void {
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')

    var date = new Date();
    var date1 = new Date();
    this.todayDate = this.datePipe.transform(date, "yyyy-MM-dd");

    this.todayDate1 = this.datePipe.transform(date1, "yyyy-MM-dd");

    this.viewCheck = localStorage.getItem('View')

       localStorage.removeItem("coustmerId");
        // this.onRestaurantsLists()
        this.onToday()
        // localStorage.removeItem("Id");
        // localStorage.removeItem("storeId");
  }

  onUsersLists(){

    let apiData = {
      pageNumber:this.p,
      creditType:"Code"
    }
    // userNumber
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onUsersListsPagination(event:any){
    this.p = event
    let apiData
    // this.onTodayStatus = false
    // this.searchStatus = false
    // this.calanderStatus = false 

    if(this.onTodayStatus == true){
       apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        // "timeframe": this.selectedValue,
      }
    }

    if(this.searchStatus == true){
      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        creditType:"Code",
        "search": this.search.value.search,
      }
    }

    if(this.calanderStatus == true){

      apiData = {
        pageNumber:this.p,
        limit: this.itemPerPage,
        "startDate": new Date(this.calanderSearch.value.startDate),
        creditType:"Code",
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }



    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
         this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
              // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch(){

    this.p = 1
    this.formvalidation.submitted = true
    if (this.search.invalid) {
      this.onToday()
      // this.service.err("Please enter cuisin name!")
      return
    }


    let apiData = {
      
    }

    // this.onTodayStatus = false
    // this.searchStatus = true
    // this.calanderStatus = false 

    if(this.calanderStatus == true){
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        creditType:"Code",
        "startDate": new Date(this.calanderSearch.value.startDate),
        "endDate": new Date(this.calanderSearch.value.endDate),
      }

    }

    if(this.onTodayStatus ==true){
      apiData = {
        pageNumber: this.p,
        limit: this.itemPerPage,
        "search": this.search.value.search,
        creditType:"Code"
        // "timeframe": this.selectedValue,

      }
    }


    console.log("apiData==>",apiData)

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }



  onCalenderSearch(){
    this.p = 1
    this.formvalidation.submitted = true

    this.onTodayStatus = false
    this.searchStatus = false
    this.calanderStatus = true 

    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
      creditType:"Code"

    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total

        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onToday(){
    this.p = 1


    this.searchStatus = false
    this.calanderStatus = false 

    let apiData = {
      pageNumber:this.p,
      limit:this.itemPerPage,
      creditType:"Code"

      // "timeframe": value,
    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onCreditListing', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.usersLists = success.data
        this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetUserId(id:any){
    this.userId = id
  }

  onActiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {
      userId: this.userId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateCreditStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.service.hideSpinner()
        this.onToday()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      userId: this.userId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateCreditStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()

        this.service.succ(success.message)
        this.onToday()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  onGetRestaurentId(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.route.navigate(['/credit-history',id])
  }

  onCouponId(id:any){
    this.couponId=id    
    this.onCouponDetails()   
  }

  onCouponDetails(){




    let apiData = {
      couponId:this.couponId
    }





    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/onParticularCreditDetails', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.couponDetails = success.data[0]

      let fromDateConvert =  this.datePipe.transform(this.couponDetails.fromDate, "yyyy-MM-dd")
      let toDateConvert =  this.datePipe.transform(this.couponDetails.toDate, "yyyy-MM-dd")

        this.createCoin.controls['creditTitle'].setValue(this.couponDetails.creditTitle);
        this.createCoin.controls['creditCode'].setValue(this.couponDetails.creditCode);
        this.createCoin.controls['totalFrequency'].setValue(this.couponDetails.totalFrequency);
        this.createCoin.controls['creditAmount'].setValue(this.couponDetails.creditAmount);
        this.createCoin.controls['fromDate'].setValue(fromDateConvert);
        this.createCoin.controls['toDate'].setValue(toDateConvert);
        this.createCoin.controls['description'].setValue(this.couponDetails.description);

        // this.usersCount = success.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  onCreateCoin() {

    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    this.formvalidation.submitted = true
    if (this.createCoin.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }

    let apiData: any = {}

    // if (this.userIdArr.length > 0) {
    //   apiData.userId = this.userIdArr
    // }else{
    //   apiData.allCustomers = "true"
    // }

    if (this.createCoin.value.creditTitle) {
      apiData.creditTitle = this.createCoin.value.creditTitle
    }

    if (this.createCoin.value.creditCode) {
      apiData.creditCode = this.createCoin.value.creditCode
    }

    // if (this.createCoin.value.creditType) {
    //   apiData.creditType = this.createCoin.value.creditType
    // }

    if (this.createCoin.value.totalFrequency) {
      apiData.totalFrequency = this.createCoin.value.totalFrequency
    }

    if (this.createCoin.value.creditAmount) {
      if (this.createCoin.value.creditAmount > 500) {
        return this.service.err("Max amount is 500")
      }
      apiData.creditAmount = this.createCoin.value.creditAmount
    }

    if (this.createCoin.value.fromDate) {
      apiData.fromDate = this.createCoin.value.fromDate
    }

    if (this.createCoin.value.toDate) {
      apiData.toDate = this.createCoin.value.toDate
    }

    if (this.createCoin.value.description) {
      apiData.description = this.createCoin.value.description
    }

    apiData.creditType = "Code"
    apiData.couponId = this.couponId

    console.log("apiData===>", apiData)

    
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateCouponCode', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        this.createCoin.reset()
        this.service.succ(success.message)
        $("#edit").modal("hide");

        this.onToday()

        // this.route.navigate(['/generated-credit-code-list'])
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }


}
