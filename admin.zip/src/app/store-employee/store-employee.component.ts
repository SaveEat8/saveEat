import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-store-employee',
  templateUrl: './store-employee.component.html',
  styleUrls: ['./store-employee.component.css']
})
export class StoreEmployeeComponent implements OnInit {
  profilePic:any=localStorage.getItem("profilePic")
  fetchId:any
  constructor() { }

  ngOnInit(): void {
    this.onFetchId()
  }

  onFetchId() {
    this.fetchId = localStorage.getItem("storeId")
  }

}
