import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';


@Injectable({
  providedIn: 'root'
})

export class AppService {
  error(response_message: any): any {
    throw new Error("Method not implemented.");
  }
  headers: any

  httpOptions: any
  // baseUrl = "http://13.234.94.41:3032"

  //dev
  // baseUrl = "http://13.234.94.41:4032"

  baseUrl = "https://saveeat.in:3035"
  // baseUrl = "https://saveeat.in:4032"



  constructor(
    public http: HttpClient,
    private spinner: NgxSpinnerService,
    private _location: Location,
    private toastrr: ToastrService
  ) { }

  getApi(url: string): Observable<any> {
    this.httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
    }
    return this.http.get(this.baseUrl + url, this.httpOptions);
  }

  getApiWithAuth(url: string): Observable<any> {
    this.httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",

      }),
    }
    return this.http.get(this.baseUrl + url, this.httpOptions);
  }

  formdataApi(url: string, data: any): Observable<any> {
    var httpOptions;
    this.httpOptions = {
      headers: new HttpHeaders(),
      observe: 'response'
    }
    return this.http.post((this.baseUrl + url), data, httpOptions)
  }

  showSpinner() {
    this.spinner.show()
  }
  hideSpinner() {
    this.spinner.hide()
  }
  backClicked() {
    this._location.back();
  }

  succ(msg:any) {
    this.toastrr.success(msg);
  }
  err(msg:any) {
    this.toastrr.error(msg);
  }

  postApi(url: any, data: any, isHeader: number): Observable<any> {
    if (!isHeader) {
      this.httpOptions = {
        headers: new HttpHeaders({ "Content-Type": "application/json" }),
      }
      return this.http.post(this.baseUrl + url, data);
    }
    else {
      this.httpOptions = {
        headers: new HttpHeaders({ "Content-Type": "application/json" }),
      }
      return this.http.post(this.baseUrl + url, data, this.httpOptions);
    }
  }


  postApiWithAuth(url: string, data: any, isHeader: any): Observable<any> {
    if (!isHeader) {
      this.httpOptions = {
        headers: new HttpHeaders({ "Content-Type": "application/json" }),
      }
    } else {
      this.httpOptions = {
        headers: new HttpHeaders({
          "Content-Type": "application/json",
        })
      }
    }
    return this.http.post(this.baseUrl + url, data, this.httpOptions);
  }


  formdataApiAuth(url: string, data: any, isHeader: any): Observable<any> {
    var httpOptions;
    if (isHeader) {
      httpOptions = {
        headers: new HttpHeaders({ 'Content': 'multipart/form-data' }),
        observe: 'response'
      }
    }
    return this.http.post((this.baseUrl + url), data, this.httpOptions)
  }

}
