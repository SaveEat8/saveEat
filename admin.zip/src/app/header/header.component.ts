import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  name:any=localStorage.getItem("name")
  profilePic:any=localStorage.getItem("profilePic")
  constructor() { }

  ngOnInit(): void {
  }

  

}
