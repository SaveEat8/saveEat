import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { DomSanitizer } from '@angular/platform-browser';

declare function uploader(): any;
@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.css']
})
export class SettingComponent implements OnInit {

  name: any = localStorage.getItem("name")
  profilePic: any = localStorage.getItem("profilePic")
  formvalidation: any = { submitted: false }
  userDetail: any;
  myForm: any = FormGroup;
  taxForm: any = FormGroup;
  profileImage: any
  fileToUpload1: any
  profilePics:any
  adminDetail:any
  adminIds:any = localStorage.getItem("superId")
  adminType= localStorage.getItem('userType');

  constructor(
    public router: Router,
    private activatedRoute: ActivatedRoute,
    public service: AppService,
    public domSanitizer: DomSanitizer,
  ) { }

  ngOnInit(): void {
    this.onGetAdmin()
    uploader();
    this.myForm = new FormGroup({
      oldPassword: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]),
      newPassword: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]),
      confirmPassword: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]),
    })

    

    this.taxForm = new FormGroup({
      tax: new FormControl('', [Validators.required]),
      fee: new FormControl('', [Validators.required]),
    })

  
    this.profilePics = localStorage.getItem("profilePic")
    
  }

  onGetAdmin(){



    let apireq = {

      adminId: localStorage.getItem("superId")
    }
    this.service.postApi('/api/v1/admin/getAdminDetailss', apireq, 1).subscribe(success => {
      console.log("success==>",success)
      if (success.status == 200) {
        this.taxForm.controls['tax'].setValue(success.data.tax);
        this.taxForm.controls['fee'].setValue(success.data.fee);

      }
      else {
        this.service.err(success.message);
      }
    }, error => {
      console.log("Something went wrong")
    })
  }

  changePassword(data: any) {

    this.formvalidation.submitted = true
    if (this.myForm.invalid) {
      return
    }

    let apireq = {
      oldPassword: data.oldPassword,
      newPassword: data.newPassword,
      adminId: localStorage.getItem("superId")
    }
    this.service.postApi('/api/v1/admin/passwordChange', apireq, 1).subscribe(success => {
      if (success.status == 200) {
        this.service.succ(success.message);
        localStorage.clear()
        this.router.navigate(['/'])
      }
      else {
        this.service.err(success.message);
      }
    }, error => {
      console.log("Something went wrong")
    })
  }

  onUpdateImage(file: any) {

    let selectedImage

    let reader = new FileReader()
    reader.readAsDataURL(file.target.files[0]);
    reader.onload = (e: any) => {
      this.profileImage = file.target.files[0]
      selectedImage =  file.target.files[0]

      console.log("this.profileImage", selectedImage)
      // console.log("this.profileImagelengthss", this.profileImage.size)
      // this.fileToUpload1 = this.domSanitizer.bypassSecurityTrustResourceUrl(URL.createObjectURL(file.target.files[0]));
      this.profilePics = this.fileToUpload1
      let adminId = localStorage.getItem("superId")
      let formData = new FormData();
      formData.append('name',  "Admin")
      formData.append('adminId',  this.adminIds)
      formData.append('profilePic',  selectedImage)

      this.service.formdataApi('/api/v1/admin/updateAdminDetail', formData).subscribe(success => {
        
        if (success.status == 200) {
          this.service.succ(success.message);
          localStorage.setItem("profilePic",success.data)
          this.profilePics = success.data
          console.log("success",success.data)


          // localStorage.clear()
          // this.router.navigate(['/'])
        }
        else {
          this.service.err(success.message);
        }
      }, error => {
        console.log("Something went wrong")

      }
      )}
  }

  onUpdateTaxAndFee(data:any){
    this.formvalidation.submitted = true
    if (this.taxForm.invalid) {
      return
    }
    let apireq = {
      tax: data.tax,
      fee: data.fee,
      adminId: localStorage.getItem("superId")
    }
    this.service.postApi('/api/v1/admin/updateAdminTaxAndSaveitfee', apireq, 1).subscribe(success => {
      if (success.status == 200) {
        this.service.succ(success.message);
        // this.router.navigate(['/'])
      }
      else {
        this.service.err(success.message);
      }
    }, error => {
      console.log("Something went wrong")
    })
  }



  

}



