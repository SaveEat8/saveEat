import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';
declare var $: any;

@Component({
  selector: 'app-sub-cuisines',
  templateUrl: './sub-cuisines.component.html',
  styleUrls: ['./sub-cuisines.component.css']
})
export class SubCuisinesComponent implements OnInit {
  p: any = 1;
  p1: any = 1;
  srNo: any;
  total: any = Number;
  pages: any;
  itemPerPage: any = 10;
  cuisines: any
  cusinesLists: any = []
  cusinesCounts: any
  brandLists: any = []
  particularCuisines: any = []
  brandsCount: any
  brandId: any
  cuisinesId: any
  formvalidation: any = { submitted: false }
  cuisinesCreate: any = FormGroup;
  cuisinesEdit: any = FormGroup;

  subCusinesLists: any = []
  subCusinesCounts: any

  subcuisinesCreate: any = FormGroup;
  subcuisinesEdit: any = FormGroup;
  search:any = FormGroup;
  calanderSearch:any = FormGroup
  profilePic:any=localStorage.getItem("profilePic")

  subCuisinesId:any
  id:any

  viewCheck:any = false
  editCheck:any = false
  blockCheck:any = false
  deleteCheck:any = false
  addCheck:any = false

  constructor(private route: Router,
    private formBuilder: FormBuilder,
    private service: AppService,
    private activatedRoute: ActivatedRoute) {
    this.cuisinesCreate = this.formBuilder.group({
      name: ['', [Validators.required]]
    });

    this.cuisinesEdit = this.formBuilder.group({
      name: ['', [Validators.required]]
    });

    this.subcuisinesCreate = this.formBuilder.group({
      name: ['', [Validators.required]]
    });

    this.subcuisinesEdit = this.formBuilder.group({
      name: ['', [Validators.required]]
    });

    this.search = this.formBuilder.group({
      search: ['', [Validators.required]]
    });

    this.calanderSearch = this.formBuilder.group({
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]]
    });

  }

  ngOnInit(): void {
    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')
    this.deleteCheck = localStorage.getItem('Delete')
    this.addCheck = localStorage.getItem('Add')
    this.getId()
  }

  getId() {
    this.activatedRoute.params.subscribe((paramsId) => {
      this.id = paramsId.id
      console.log('Check',this.id)
    })

    this.onSubCuisines(this.id)

  }

  onSubCuisines(id: any) {
    this.cuisinesId = id

    let apiData = {
      cuisineId: id,
      pageNumber: this.p1,
      limit: this.itemPerPage
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineSubCategoryList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.subCusinesLists = success.data.docs
        this.subCusinesCounts = success.data.total
        console.log("this.subCusinesCounts===>",this.subCusinesCounts)
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSubCuisinesPagination(event: any) {
    this.p1 = event

    let apiData = {
      cuisineId: this.cuisinesId,
      pageNumber: this.p1,
      limit: this.itemPerPage
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineSubCategoryList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)
      if (success.status == 200) {
        this.service.showSpinner()
        console.log("success==>", success)
        this.subCusinesLists = success.data.docs
        this.subCusinesCounts = success.data.total
        this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onSearch(){
    this.p = 1
    this.formvalidation.submitted = true
    if (this.search.invalid) {
      this.onSubCuisines( this.cuisinesId)
      // this.service.err("Please enter cuisin name!")
      return
    }

    let apiData = {
      pageNumber: this.p,
      limit: this.itemPerPage,
      cuisineId: this.cuisinesId,
      "search": this.search.value.search,
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineSubCategoryList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.subCusinesLists = success.data.docs
        this.subCusinesCounts = success.data.total
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onParticularSubCuisinesData(id: any) {
    this.subCuisinesId = id

    let apiData = {
      cuisineCategoryId: id,

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/particularSubCuisine', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
                this.service.hideSpinner()
        console.log("success==>", success.Data.name)
        // this.brandLists = success.Data
        this.subcuisinesEdit.controls['name'].setValue(success.Data.name);

        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onCreateSubCuisines(cuisinData: any) {
    if(this.addCheck == false){
      return this.service.err("User Not allowed to perform this action")
    }
    this.formvalidation.submitted = true
    if (this.subcuisinesCreate.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }

    let apiData = {
      "name": cuisinData.name,
      "cuisineId":  this.cuisinesId
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/addCuisineCategory', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        $("#SubCuisines").modal("hide");
        this.subcuisinesCreate.reset()
        this.service.succ(success.message)
        this.onSubCuisines( this.cuisinesId)
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

  onUpdateSubCuisines(cuisinData: any) {
    if(this.editCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    this.formvalidation.submitted = true
    if (this.subcuisinesEdit.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }
    let apiData = {
      cuisineCategoryId: this.subCuisinesId,
      name: cuisinData.name

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateCuisineCategory', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        // console.log("success==>",success.Data.name)
        // this.brandLists = success.Data

        this.service.hideSpinner()
        $("#Edit_SubCuisines").modal("hide");
        this.subcuisinesEdit.reset()
        this.service.succ(success.message)
        this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDeleteSubCuisinesId(id: any) {
    this.subCuisinesId = id
  }

  onDeleteSubCuisines() {
    if(this.deleteCheck == false){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      cuisineCategoryId: this.subCuisinesId,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/deleteCuisineCategory', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        $("#Subdelete").modal("hide");
        this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onActiveSubcusines(){
    // statusUpdateCuisineCategory
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      cuisineCategoryId: this.subCuisinesId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/statusUpdateCuisineCategory', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        $("#Active").modal("hide");
        this.onSubCuisines(this.id)

        // this.onRestaurantsLists()
        // this.onBrandLists(this.brandId)
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInActiveSubcusines(){
    // statusUpdateCuisineCategory
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      cuisineCategoryId: this.subCuisinesId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/statusUpdateCuisineCategory', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.showSpinner()
        this.service.succ(success.message)
        $("#Inactive").modal("hide");
        this.onSubCuisines(this.id)

        // this.onRestaurantsLists()
        // this.onBrandLists(this.brandId)
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }


  onCalenderSearch(){
    // this.p = 1
    this.formvalidation.submitted = true
    if (this.calanderSearch.invalid) {
      // this.onCuisinesLists()
      // this.service.err("Please enter cuisin name!")
      return
    }

  //   let startDate =  new Date(this.calanderSearch.value.startDate);
  //   let endDate = new Date(this.calanderSearch.value.endDate);

  //  let updatedStartDate = startDate.setDate(startDate.getDate()+1)
  //  let updatedendDate = endDate.setDate(startDate.getDate()+1)


  //   let startDates = new Date(updatedStartDate)
  //   let endDates = new Date()



    let apiData = {
      cuisineId: this.cuisinesId,
      pageNumber: this.p,
      limit: this.itemPerPage,
      "startDate": new Date(this.calanderSearch.value.startDate),
      "endDate": new Date(this.calanderSearch.value.endDate),
    }

    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/cuisineSubCategoryList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.subCusinesLists = success.data.docs
        this.subCusinesCounts = success.data.total
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onRefresh(){
    window.location.reload();
  }

}