import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';

import * as xlsx from 'xlsx';


declare var $: any

@Component({
  selector: 'app-store-menu',
  templateUrl: './store-menu.component.html',
  styleUrls: ['./store-menu.component.css']
})
export class StoreMenuComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;
  profilePic: any = localStorage.getItem("profilePic")
  fetchId: any

  p: any = 1;
  p1: any = 1;
  srNo: any;
  total: any = Number;
  pages: any;
  itemPerPage: any = 10;
  menuLists: any = []
  menuCount: any
  menuId: any
  getBrandId: any
  restaurantId: any
  itemList: any = []
  itemcount: any

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.onFetchId()
    this.onMenuLists()
  }

  onFetchId() {
    this.fetchId = localStorage.getItem("storeId")
  }

  onMenuLists() {

    let apiData = {
      brandId: localStorage.getItem("storeId"),
      pageNumber: this.p

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/menuList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.menuLists = success.Data
        this.menuCount = success.TotalCount
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onMenuListsPagination(event: any) {
    this.p = event
    let apiData = {
      brandId: localStorage.getItem("storeId"),
      pageNumber: this.p

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/menuList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.menuLists = success.Data
        this.menuCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetMenu(id: any) {
    console.log("id==>", id)
    this.menuId = id
  }

  onApproveMenu() {
    let apiData = {
      menuId: this.menuId,
      status: "Approve"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/verifyMenu', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        this.onMenuLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDisApproveMenu() {
    let apiData = {
      menuId: this.menuId,
      status: "Disapprov"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/verifyMenu', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        this.onMenuLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onActiveStatus() {
    let apiData = {
      menuId: this.menuId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateMenuStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        this.onMenuLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus() {
    let apiData = {
      menuId: this.menuId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/updateMenuStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.onMenuLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDeleteMenu() {
    let apiData = {
      menuId: this.menuId,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/deleteMenu', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        $("#Subdelete").modal("hide");
        this.onMenuLists()

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onItemList(id: any) {

    let apiData = {
      brandId: localStorage.getItem("storeId"),
      menuId: id,
      pageNumber: this.p1

    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/itemList', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>", success)
        this.itemList = success.data.docs
        this.itemcount = success.TotalCount
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  ChangeStatus(event: any) {
    let address = $('#address1').val()
    console.log("address", event.target.checked)
  }

  exportToExcel() {
    const ws: xlsx.WorkSheet =
      xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'itemList.xlsx');
  }



}
