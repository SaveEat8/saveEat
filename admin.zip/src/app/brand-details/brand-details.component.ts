import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brand-details',
  templateUrl: './brand-details.component.html',
  styleUrls: ['./brand-details.component.css']
})
export class BrandDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
