import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';

declare function password():any;
@Component({
  selector: 'app-add-users',
  templateUrl: './add-users.component.html',
  styleUrls: ['./add-users.component.css']
})
export class AddUsersComponent implements OnInit {

  formvalidation: any = { submitted: false }
  subAdminCreate: any = FormGroup;
  roleList:any = []

  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder) {
      this.subAdminCreate = this.formBuilder.group({
        name: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/)]],
        mobileNumber: ['', [Validators.required, Validators.required,Validators.minLength(10), Validators.maxLength(10)]],
        password: ['', [Validators.required,Validators.minLength(6), Validators.maxLength(16)]],
        role:['', [Validators.required]]
      });
     }

  ngOnInit(): void {
    password()
    this.onRoleList()
  }

  

  onRoleList() {

    let apiData = {
    }

    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/adminAllRoleList', apiData, 1).subscribe((success) => {
      console.log("success",success)
      if (success.status == 200) {
        this.service.hideSpinner()

        this.roleList = success.data
        
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }


  onCreateSubadmin(cuisinData: any) {
    this.formvalidation.submitted = true
    if (this.subAdminCreate.invalid) {
      // this.service.err("Please enter cuisin name!")
      return
    }

    let apiData = {
      "name": cuisinData.name,
      "password": cuisinData.password,
      "mobileNumber": cuisinData.mobileNumber,
      "email": cuisinData.email,
      "role": cuisinData.role
    }
console.log("apiData===>",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/admin/createSubAdmin', apiData, 1).subscribe((success) => {
      if (success.status == 200) {
        this.service.hideSpinner()
        this.subAdminCreate.reset()
        this.service.succ(success.message)
      this.route.navigate(['/users'])
      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })

  }

}
