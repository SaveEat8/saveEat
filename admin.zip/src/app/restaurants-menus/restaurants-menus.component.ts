import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AppService } from '../app.service';

import * as xlsx from 'xlsx';


declare var $:any
@Component({
  selector: 'app-restaurants-menus',
  templateUrl: './restaurants-menus.component.html',
  styleUrls: ['./restaurants-menus.component.css']
})
export class RestaurantsMenusComponent implements OnInit {
  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  profilePic:any=localStorage.getItem("profilePic")
  fetchId:any
  p: any = 1;
  p1:any = 1;
  srNo: any;
  total:any = Number;
  pages :any;
  itemPerPage: any = 10;
  menuLists:any = []
  menuCount:any
  menuId:any
  getBrandId:any
  restaurantId:any
  itemList:any = []
  itemcount:any

  viewCheck:any = false
  editCheck:any = false
  blockCheck:any = false
  deleteCheck:any = false
  addCheck:any = false
  adminType= localStorage.getItem('userType');

  itemId:any
  constructor(private route: Router,
    private service: AppService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.viewCheck = localStorage.getItem('View')
    this.editCheck = localStorage.getItem('Edit')
    this.blockCheck = localStorage.getItem('Block')
    this.deleteCheck = localStorage.getItem('Delete')
    this.addCheck = localStorage.getItem('Add')

    this.onFetchId()
    this.onMenuLists()
  }

  onFetchId(){
    this.fetchId = localStorage.getItem("restorentId")
  }

  onMenuLists(){

    let apiData = {
      brandId:localStorage.getItem("restorentId"),
      pageNumber:this.p

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/menuList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.menuLists = success.Data
        this.menuCount = success.TotalCount
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onMenuListsPagination(event:any){
    this.p = event
    let apiData = {
      brandId:localStorage.getItem("restorentId"),
      pageNumber:this.p

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/menuList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.response_code == 200) {
                this.service.hideSpinner()
        console.log("success==>",success)
        this.menuLists = success.Data
        this.menuCount = success.TotalCount
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onGetMenu(id:any){
    console.log("id==>",id)
    this.menuId = id
  }



  onApproveMenu(){

    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }

    let apiData = {
      menuId: this.menuId,
      status: "Approve"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/verifyMenu', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        this.onMenuLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDisApproveMenu(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      menuId: this.menuId,
      status: "Disapprov"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/verifyMenu', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        this.onMenuLists()
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onActiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      menuId: this.menuId,
      status: "Active"
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/updateProdutStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        this.onItemList(this.itemId)
        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onInactiveStatus(){
    if(this.blockCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      menuId: this.menuId,
      status: "Inactive"
    }
    console.log("data", apiData)
    this.service.hideSpinner()
    this.service.postApi('/api/v1/adminUser/updateProdutStatus', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.succ(success.message)
        this.onItemList(this.itemId)        // $("#Subdelete").modal("hide");
        // this.onSubCuisines( this.cuisinesId)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onDeleteMenu() {
    if(this.deleteCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    let apiData = {
      menuId: this.menuId,
    }
    console.log("data", apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/deleteMenu', apiData, 1).subscribe((success) => {
      console.log("success==>", success)

      if (success.status == 200) {
        this.service.hideSpinner()
        this.service.succ(success.message)
        $("#Subdelete").modal("hide");
        this.onMenuLists()

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  onItemList(id:any){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }
    this.itemId = id

    let apiData = {
      brandId:localStorage.getItem("restorentId"),
      menuId:id,
      pageNumber:this.p1

    }
    console.log("data",apiData)
    this.service.showSpinner()
    this.service.postApi('/api/v1/adminUser/itemList', apiData, 1).subscribe((success) => {
      console.log("success==>",success)

      if (success.status == 200) {
        this.service.hideSpinner()
        console.log("success==>",success)
        this.itemList = success.data.docs
        this.itemcount = success.TotalCount
        // this.service.hideSpinner()
        // this.service.succ(success.message)

      }
      else {
        this.service.hideSpinner()
        this.service.err(success.message)
      }
    }, error => {
      this.service.hideSpinner()
    })
  }

  ChangeStatus(event:any){
    let address =  $('#address1').val() 
console.log("address",event.target.checked)
  }

  exportToExcel() {
    const ws: xlsx.WorkSheet =
    xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'itemList.xlsx');
  }

  onView1(){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
    }


  }

  onViewCheck3(){
    if(this.viewCheck == 'false'){
      return this.service.err("User Not allowed to perform this action")
  }



}




}
