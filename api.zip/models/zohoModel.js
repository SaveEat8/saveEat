const mongoose = require("mongoose");

let Schema = mongoose.Schema;
const modelSchema = new mongoose.Schema({

    access_token: {
        type: String
    },
    refresh_token: {
        type: String
    },
    api_domain: {
        type: String
    },
    token_type: {
        type: String
    },
    expires_in: {
        type: Number
    }
}, {
    timestamps: true
})

const models = new mongoose.model('zoho_tokens', modelSchema);

module.exports = models;