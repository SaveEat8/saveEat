const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let db = mongoose.connection;
let Schema = mongoose.Schema;
let Rescuefood = mongoose.Schema({

    storeId: { type :Schema.Types.ObjectId,ref:"brands"},
    userId: { type :Schema.Types.ObjectId,ref:"users"},
    orderId: { type :Schema.Types.ObjectId,ref:"productorders"},
    rescueFood:{
        type:Number
    },
    day:{
        type:Number
    },
    month:{
        type:Number
    },
    year:{
        type:Number
    }
},{
    timestamps: true
})
Rescuefood.plugin(mongoosePaginate)
Rescuefood.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('rescuefoods', Rescuefood);