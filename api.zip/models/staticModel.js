var mongoose = require('mongoose');
var schema = mongoose.Schema;
var static_content = new schema({

    title: {
        type: String,
        trim: true
    },
    description: {
        type: String,
        trim: true
    },
    status: {
        type: String,
        enum: ['Active', 'Inactive'],
        default: "Active"
    },
    type: {
        type: String,
        trim: true
    },
    email: {
        type: String,
        trim: true
    },
    companyName:{
        type: String,
        trim: true
    },
    companyAddress:{
        type: String,
        trim: true
    },
    contactNumber: {
        type: String,
        trim: true
    },
    webisteUrl:{
        type:String,
        trim:true
    },
    userType: {
        type: String
    }
},
    { timestamps: true }
);

module.exports = mongoose.model('static_content', static_content);
mongoose.model('static_content', static_content).find((error, result) => {
    if (result.length == 0) {
        let obj = {
            'title': "Terms of Conditions",
            'description': "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
            'type': 'termsAndConditions',
            'userType': 'User'

        };
        mongoose.model('static_content', static_content).create(obj, (error, success) => {
            if (error)
                console.log("Error is" + error)
            else
                console.log("Terms of Condition saved succesfully.", success);
        })
    }
});

mongoose.model('static_content', static_content).find((error, result) => {
    if (result.length == 0) {
        let obj1 = {
            'title': "About Us",
            'description': "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
            'type': 'aboutUs',
            'userType': 'User'

        };
        mongoose.model('static_content', static_content).create(obj1, (error, success) => {
            if (error)
                console.log("Error is" + error)
            else
                console.log("About Us details saved succesfully.", success);
        })
    }
});
mongoose.model('static_content', static_content).find((error, result) => {
    if (result.length == 0) {
        let obj1 = {
            'title': "Contact Us",
            'description': "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
            'type': 'contactUs',
            'userType': 'User'

        };
        mongoose.model('static_content', static_content).create(obj1, (error, success) => {
            if (error)
                console.log("Error is" + error)
            else
                console.log("Contact Us details saved succesfully.", success);
        })
    }
});
mongoose.model('static_content', static_content).find((error, result) => {
    if (result.length == 0) {
        let obj1 = {
            'title': "Privacy Policy",
            'description': "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
            'type': 'privacyPlicy',
            'userType': 'User'

        };
        mongoose.model('static_content', static_content).create(obj1, (error, success) => {
            if (error)
                console.log("Error is" + error)
            else
                console.log("Privacy details saved succesfully.", success);
        })
    }
});




