let mongoose = require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let Schema = mongoose.Schema;
let Address = mongoose.Schema({

    userId: { type: Schema.Types.ObjectId,ref: "user" },
    status: {
        type: String,
        enum: ['Active', 'Inactive'],
        default: 'Active'
    },
    deleteStatus:{
        type:Boolean,
        default:false
    },
    house:{
        type:String,
        trim:true
    },
    landmark:{
        type:String
    },
    directions:{
        type:String
    },
    saveAs:{
        type:String
    },
    completeAddress:{
        type:String
    },
    latitude:{
        type:Number
    },
    longitude:{
        type:Number
    },
    location: {
        type: { type: String, default: 'Point', enum: ['Point'] },
        coordinates: [{ type: Number, createIndexes: true }],
    },
    defaultStatus:{
        type:Boolean,
        default:false
    }
}, {
    timestamps: true
})
Address.index({ location: '2dsphere' });
Address.plugin(mongoosePaginate)
Address.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('user_addresss', Address);