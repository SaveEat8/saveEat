let mongoose = require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let Schema = mongoose.Schema;
let Reward = mongoose.Schema({

    userId: { type: Schema.Types.ObjectId,ref: "users" },
    rewardNumber:{
        type:String
    },
    claimedStatus: {
        type: String,
        enum:["Claimed","Unclaimed"],
        default:'Unclaimed'
    },
    claimedDate:{
        type:Date
    },
    rewardType:{
        type:String,
        enum:['Plant','Credit']
    } 
}, {
    timestamps: true
})
Reward.plugin(mongoosePaginate)
Reward.plugin(mongooseAggregatePaginate);
module.exports  = mongoose.model('rewards', Reward);
