let mongoose = require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let Schema = mongoose.Schema;
let Store = mongoose.Schema({

    storeId: { type: Schema.Types.ObjectId,ref: "stores" },
    brandId: { type: Schema.Types.ObjectId,ref: "brands" },
    roleId: { type: Schema.Types.ObjectId,ref: "roles" },
    location: {
        type: { type: String, default: 'Point', enum: ['Point'] },
        coordinates: [{ type: Number, createIndexes: true }],
    },
    businessName:{
        type:String,
        trim:true
    },
    adminVerificationStatus:{
        type:String,
        enum:['Pending','Approve','Disapprov'],
        default:'Pending'
    },
    status: {
        type: String,
        enum:['Active','Inactive'],
        default:'Active'
    },
    userType: {
        type: String,
        default:'Store'
    },
    description:{
        type:String
    },
    jwtToken: {
        type: String,
        trim:true
    },
    multipleStore:{
        type:Boolean
    },
    street:{
        type:String,
        trim:true
    },
    locality:{
        type:String
    },
    countryCode:{
        type:String
    },
    mobileNumber:{
        type:String,
        trim:true
    },
    webiteLink:{
        type:String
    },
    gstinNumber:{
        type:String
    },
    fssaiNumber:{
        type:String
    },
    email:{
        type:String
    },
    password:{
        type:String,
        trim:true
    },
    deviceType:{
        type:String,
        trim:true
    },
    deviceToken:{
        type:String,
        trim:true
    },
    image:{
        type:String,
        trim:true,
        default:'https://www.logopik.com/wp-content/uploads/edd/2018/07/Restaurant-Logo-Vector-Design.png'
    },
    logo:{
        type:String,
        trim:true,
        default:'https://www.logopik.com/wp-content/uploads/edd/2018/07/Restaurant-Logo-Vector-Design.png'
    },
    deleteStatus:{
        type:Boolean,
        default:false
    },
    notificationStatus:{
        type:Boolean,
        default:true
    },
    latitude:{
        type:String
    },
    longitude:{
        type:String
    },
    address:{
        type:String,
        trim:true
    },
    totalRating:{
        type:Number,
        default:0
    },
    avgRating:{
        type:Number,
        default:0
    },
    ratingByUsers:{
        type:Number,
        default:0
    },
    totalOrders:{
        type:Number,
        default:0
    },
    emailOtp:{
        type:String
    },
    businessType:{
        type:String
    },
    empId:{
        type:String
    },
    name:{
        type:String
    },
    role:{
        type:String
    },
    foodType:{
        type:String,
        enum:['Veg','Non-Veg','Both']
    },
    bankName:{
        type:String
    },
    accountHolderName:{
        type:String
    },
    accountNumber:{
        type:String
    },
    ifscCode:{
        type:String
    },
    badge:{
        type:String,
        default:'Silver'
    },
    originalName:{
        type:String
    },
    originalEmail:{
        type:String
    },
    originalMobileNumber:{
        type:String
    },
    language:{
        type:String,
        default:'English'
    },
    followers:{
        type:Number,
        default:0
    },
    openStatus:{
        type:String,
        enum:['Open','Close'],
        default:'Open'
    }
}, {
    timestamps: true
})
Store.index({ location: '2dsphere' });
Store.plugin(mongoosePaginate)
Store.plugin(mongooseAggregatePaginate);
module.exports  = mongoose.model('stores', Store);
