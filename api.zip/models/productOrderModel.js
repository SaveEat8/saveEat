const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let db = mongoose.connection;
let Schema = mongoose.Schema;
let Productorder = mongoose.Schema({

    storeId: {
        type: Schema.Types.ObjectId,
        ref: "brands"
    },
    userId: {
        type: Schema.Types.ObjectId,
        ref: "users"
    },
    orderData: [{
        productId: {
            type: Schema.Types.ObjectId,
            ref: "products"
        },
        quantity: {
            type: Number
        },
        price: {
            type: Number
        },
        actualAmount: {
            type: Number
        },
        discountAmount: {
            type: Number
        },
        amountWithQuantuty: {
            type: Number
        },
        productData: {},
        extra: [],
        choiceAmount: {
            type: Number
        },
        mainChoice: [],
        tax: {
            type: Number
        },
        withTax: {
            type: Number
        },
        productAmount: {
            type: Number
        },
        actualproductAmount: {
            type: Number
        },
        productAmountWithChoice: {
            type: Number
        },
        productDiscountAmount: {
            type: Number
        },
        requirement: {
            type: String
        },
        commissonAmount: {
            type: Number
        },
        brandAmount: {
            type: Number
        }
    }],
    type: {
        type: String,
        enum: ['Stote', 'Brand'],
    },
    pickupDate: {
        type: String
    },
    pickupTime: {
        type: String
    },

    convertedPickupDate: {
        type: Date
    },
    actualOrderDate: {
        type: String
    },
    orderDate: {
        type: String
    },
    orderType: {
        type: String,
        enum: ['Now', "Later"],
        default: 'Now'
    },
    orderNumber: {
        type: String
    },
    subTotal: {
        type: Number
    },
    offerPrice: {
        type: Number
    },
    total: {
        type: Number
    },
    status: {
        type: String,
        enum: ['Pending', 'Accepted', 'Rejected', 'Cancelled', 'On the way', 'Out for delivery', 'Delivered', 'Arrived', 'Order Ready for pickup', 'No Show', 'Driver Accepted', 'Waiting for Driver', 'Order Picked Up'],
        default: 'Pending'
    },
    currency: {
        type: String
    },
    day: {
        type: Number
    },
    month: {
        type: Number
    },
    year: {
        type: Number
    },
    ratingStatus: {
        type: Boolean,
        default: false
    },
    timezone: {
        type: String
    },
    saveAmount: {
        type: Number,
        default: 0
    },
    tax: {
        type: Number
    },
    roundOff: {
        type: Number,
        default: 0
    },
    paymentStatus: {
        type: String,
        enum: ['Pending', 'Complete'],
        default: 'Pending'
    },
    qrCode: {
        type: String
    },
    pin: {
        type: String
    },
    refundStatus: {
        type: String,
        default: 'Not-Applicable'
    },
    commissionPer: {
        type: Number,
        default: 0
    },
    fixCommissionPer: {
        type: Number,
        default: 0
    },
    commissionAmount: {
        type: Number,
        default: 0
    },
    orderAcceptedTime: {
        type: Date
    },
    orderRejectedTime: {
        type: Date
    },
    orderCancelledTime: {
        type: Date
    },
    orderDeliveredTime: {
        type: Date
    },
    orderReadyForPickupTime: {
        type: Date
    },
    rescusedFood: {
        type: Number
    },
    storeAmount: {
        type: Number
    },
    adminAmount: {
        type: Number
    },
    orderFullSubTotal: {
        type: Number
    },
    orderFullTax: {
        type: Number
    },
    orderFullTotal: {
        type: Number
    },
    paymentMode: {
        type: String
    },
    orderFullSaveAmount: {
        type: Number
    },
    paymentId: {
        type: String
    },
    paymentStatus: {
        type: String
    },
    priceObj: {
        type: Object
    },
    saveEatFees: {
        type: Number,
    },
    taxes: {
        type: Number
    },
    storeProceeds: {
        type: Number
    },
    totalCommissionAmount: {
        type: Number
    },
    showStoreAmount: {
        type: Number
    },
    deductedPoints: {
        type: Number
    },

    zohoId: {
        type: String
    },

    //delivery
    deliveryDate: {
        type: String
    },
    deliveryTime: {
        type: String
    },
    // deliveryFee: {
    //     type: Number
    // },

    //dunzoo
    driverNumber: {
        type: String
    },
    driverName: {
        type: String
    },
    dunzoDeliveryFee: {
        type: Number
    },
    deliveryFee: {
        type: Number
    },
    estimated_time:{
        type:Number
    } ,
    orderServiceType: {
        type: String,
    },
    dunzoTaskId: {
        type: String
    },
    addressData: {
        type: Object
    },
    dunzoDriverState: {
        type: String
    },
    dunzoDriverStateTimeline: {
        type: [{
            state: {
                type: String
            },
            created_at: {
                type: Date,
                default: Date.now,
                select: false
            }
        }]
    },
    dunzoData: {
        type: Object
    },
    trackingUrl: {
        type: String
    },
    dunzoError: {
        type: Object
    },


}, {
    timestamps: true
})
Productorder.plugin(mongoosePaginate)
Productorder.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('productorders', Productorder);