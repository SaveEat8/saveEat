const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let db = mongoose.connection;
let Schema = mongoose.Schema;
let refund = mongoose.Schema({


    storeId: { type :Schema.Types.ObjectId,ref:"brands"},

    orderId:{ type :Schema.Types.ObjectId,ref:"productorders" },

    userId: { type :Schema.Types.ObjectId,ref:"users"},

    adminId:{ type :Schema.Types.ObjectId,ref:"admin"},
    
    refundAmount:{ type:Number,
        default:0
     },

     reason:{
         type:String
     },

     refundType:{
        type:String,
        enum:['Amount','Credit'],
        default:"Credit"
     },

     refundNumber:{
         type:String
     },

     refundedBy:{
         type:String,
         enum:['Admin','SubAdmin'],
         default:"Admin"
     }



},{
    timestamps: true
})
refund.plugin(mongoosePaginate)
refund.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('refunds', refund);