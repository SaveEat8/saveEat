const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let db = mongoose.connection;
let Schema = mongoose.Schema;
let Sellingitems = mongoose.Schema({

    brandId: { type :Schema.Types.ObjectId,ref:"brands"},
    productId: { type :Schema.Types.ObjectId,ref:"products"},
    day:{
        type:Number
    },
    month:{
        type:Number
    },
    year:{
        type:Number
    },
    date:{
        type:String
    },
    status:{
        type:String,
        enum:['Start','Stop'],
        default:'Start'
    },
    startDate:{
        type:Date
    },
    endDate:{
        type:Date
    },
    quantity:{
        type:Number
    },
    amount:{
        type:Number
    }
},{
    timestamps: true
})
Sellingitems.plugin(mongoosePaginate)
Sellingitems.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('sellingitemss', Sellingitems);