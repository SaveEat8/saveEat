const mongoose = require('mongoose');
var Schema = mongoose.Schema;
const mongoosePaginate = require('mongoose-paginate');
var Promocode = mongoose.Schema({

    brandId: { type: Schema.Types.ObjectId, ref: "brands" },
    branchId: { type: Schema.Types.ObjectId, ref: "branchs" },
    itemId: { type: Schema.Types.ObjectId, ref: "products" },
    status: {
        type: String,
        enum: ['Active', 'Inactive'],
        default: 'Active'
    },
    adminVerificationStatus:{
        type:String,
        enum:['Pending','Approve','Disapprov'],
        default:'Pending'
    },
    fromDate:{
        type:Date
    },
    todate:{
        type:Date
    },
    code:{
        type:String
    },
    discountType:{
        type:String,
        trim:true
    },
    discount:{
        type:Number
    },
    deleteStatus:{
        type:Boolean,
        default:false
    }
},
    { timestamps: true }
);

Promocode.plugin(mongoosePaginate)
module.exports = mongoose.model('promocodes', Promocode);