let mongoose = require('mongoose');
let schema = mongoose.Schema;
let social_media = new schema({

    link: {
        type: String,
        trim: true
    },
    status: {
        type: String,
        enum: ['Active', 'Inactive'],
        default: "Active"
    },
    type: {
        type: String,
        trim: true
    }
},
    { timestamps: true }
);

module.exports = mongoose.model('social_media', social_media);
mongoose.model('social_media', social_media).find((error, result) => {
    if (result.length == 0) {
        let obj = {
            'link': "https://www.facebook.com/saveeat",
            'type': 'Facebook'
        };
        mongoose.model('social_media', social_media).create(obj, (error, success) => {
            if (error)
                console.log("Error is" + error)
            else
                console.log("Facebook link saved succesfully.", success);
        })
    }
});
mongoose.model('social_media', social_media).find((error, result) => {
    if (result.length == 0) {
        let obj = {
            'link': "https://www.instagram.com/saveeat",
            'type': 'Instagram'
        };
        mongoose.model('social_media', social_media).create(obj, (error, success) => {
            if (error)
                console.log("Error is" + error)
            else
                console.log("Instagram link saved succesfully.", success);
        })
    }
});
mongoose.model('social_media', social_media).find((error, result) => {
    if (result.length == 0) {
        let obj = {
            'link': "https://www.twitter.com/saveeat",
            'type': 'Twitter'
        };
        mongoose.model('social_media', social_media).create(obj, (error, success) => {
            if (error)
                console.log("Error is" + error)
            else
                console.log("Twitter link saved succesfully.", success);
        })
    }
});
mongoose.model('social_media', social_media).find((error, result) => {
    if (result.length == 0) {
        let obj = {
            'link': "https://www.youtube.com/saveeat",
            'type': 'Youtube'
        };
        mongoose.model('social_media', social_media).create(obj, (error, success) => {
            if (error)
                console.log("Error is" + error)
            else
                console.log("Youtube link saved succesfully.", success);
        })
    }
});





