let mongoose = require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let Schema = mongoose.Schema;
let User = mongoose.Schema({

    location: {
        type: { type: String, default: 'Point', enum: ['Point'] },
        coordinates: [{ type: Number, createIndexes: true }],
    },
    status: {
        type: String,
        enum:['Active','Inactive'],
        default:'Active'
    },
    jwtToken: {
        type: String,
        trim:true
    },
    name:{
        type:String,
        trim:true
    },
    gender: {
        type: String,
        default: ''
    },
    userType: {
        type: String,
        default:'User'
    },
    countryCode:{
        type:String,
        default:'+91'
    },
    mobileNumber:{
        type:String,
        trim:true
    },
    email:{
        type:String
    },
    password:{
        type:String,
        trim:true
    },
    deviceType:{
        type:String,
        trim:true
    },
    deviceToken:{
        type:String,
        trim:true
    },
    profilePic:{
        type:String,
        trim:true,
        default:'https://res.cloudinary.com/a2karya80559188/image/upload/v1630310020/Profile_avatar_qzt5dd.png'
    },
    socialType:{
        type:String,
        trim:true
    },
    socialId:{
        type:String,
        trim:true
    },
    deleteStatus:{
        type:Boolean,
        default:false
    },
    notificationStatus:{
        type:Boolean,
        default:true
    },
    latitude:{
        type:String
    },
    longitude:{
        type:String
    },
    address:{
        type:String,
        trim:true
    },
    totalOrders:{
        type:Number,
        default:0
    },
    totalCancelledOrders:{
        type:Number,
        default:0
    },
    foodRescure:{
        type:Number,
        default:0
    },
    savedMoney:{
        type:Number,
        default:0
    },
    walletAmount:{
        type:Number,
        default:0
    },
    userNumber:{
        type:String
    },
    lastOrderDate:{
        type:Date
    },
    distance:{
        type:Number
    },

    zohoId:{
        type:String
    }
    
}, {
    timestamps: true
})
User.index({ location: '2dsphere' });
User.plugin(mongoosePaginate)
User.plugin(mongooseAggregatePaginate);
module.exports  = mongoose.model('users', User);
