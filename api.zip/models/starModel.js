let mongoose = require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let Schema = mongoose.Schema;
let Star = mongoose.Schema({

    userId: { type: Schema.Types.ObjectId,ref: "users" },
    orderId: { type: Schema.Types.ObjectId,ref: "orders" },
    star:{
        type:Number,
        default:1
    },
    day:{
        type:Number
    },
    month:{
        type:Number
    },
    year:{
        type:Number
    } 
}, {
    timestamps: true
})
Star.plugin(mongoosePaginate)
Star.plugin(mongooseAggregatePaginate);
module.exports  = mongoose.model('stars', Star);
