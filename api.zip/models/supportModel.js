const mongoose = require('mongoose');
var Schema = mongoose.Schema;
const mongoosePaginate = require('mongoose-paginate');
var Support = mongoose.Schema({

    brandId: { type: Schema.Types.ObjectId, ref: "brands" },
    branchId: { type: Schema.Types.ObjectId, ref: "branchs" },
    email:{
        type:String
    },
    inquiryType:{
        type:String
    },
    inquiryReason:{
        type:String
    },
    concern: {
        type: String,
        trim: true
    },
    file:{
        type:String
    },
    status: {
        type: String,
        enum: ['Active', 'Close', 'Pending'],
        default: 'Pending'
    }
},
    { timestamps: true }
);

Support.plugin(mongoosePaginate)
module.exports = mongoose.model('supports', Support);