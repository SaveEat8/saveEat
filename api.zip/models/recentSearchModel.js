const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const mongoosePaginate = require('mongoose-paginate');
const Recentsearch = mongoose.Schema({

    userId: { type: Schema.Types.ObjectId, ref: "users" },
    status: {
        type: String,
        enum: ['Active', 'Inactive'],
        default: 'Active'
    },
    search: {
        type: String
    }
},
    { timestamps: true }
);

Recentsearch.plugin(mongoosePaginate)
module.exports = mongoose.model('recentsearchs', Recentsearch);