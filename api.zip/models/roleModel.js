let mongoose = require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let Schema = mongoose.Schema;
let Role = mongoose.Schema({

    brandId: { type: Schema.Types.ObjectId, ref: "brands" },
    status: {
        type: String,
        enum: ['Active', 'Inactive'],
        default: 'Active'
    },
    deleteStatus:{
        type:Boolean,
        default:false
    },
    roleTitle:{
        type:String
    },
    description:{
        type:String
    },
    roleNumber:{
        type:String
    },
    modules:[],
    accessibility:[]
}, {
    timestamps: true
})
Role.plugin(mongoosePaginate)
Role.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('roles', Role);