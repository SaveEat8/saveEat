const mongoose = require('mongoose');
var Schema = mongoose.Schema;
const mongoosePaginate = require('mongoose-paginate');
var Storerating = mongoose.Schema({

    userId: { type: Schema.Types.ObjectId, ref: "users" },
    soreId: { type: Schema.Types.ObjectId, ref: "stores" },
    brandId: { type: Schema.Types.ObjectId, ref: "brands" },
    orderId: { type: Schema.Types.ObjectId, ref: "productorders" },
    status: {
        type: String,
        enum: ['Active', 'Inactive'],
        default: 'Active'
    },
    rating: {
        type: Number
    },
    review: {
        type: String
    }

},
    { timestamps: true }
);
Storerating.plugin(mongoosePaginate)
module.exports = mongoose.model('storeratings', Storerating);