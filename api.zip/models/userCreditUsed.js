let mongoose = require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
let Schema = mongoose.Schema;
let Credit = mongoose.Schema({

    userId: { type: Schema.Types.ObjectId,ref: "users" },
    orderId: { type: Schema.Types.ObjectId,ref: "productorders" },
    debitNumber:{
        type:String
    },
    debitTitle:{
        type:String,
        trim:true
    },
    // debitCode:{
    //     type:String,
    //     trim:true
    // },  
    // creditType:{
    //     type: String,
    //     enum: ['Direct', 'Code'],
    //     default: 'Direct'
    // },
    transectionType:{
        type: String,
        enum: ['Credit', 'Debit'],
        default: 'Debit'
    },
    status: {
        type: String,
        enum: ['Active', 'Inactive','Expired','Used'],
        default: 'Active'
    },
    debitAmount: {
        type: Number,
        trim:true
    },
    // remaningAmount: {
    //     type: Number,
    //     trim:true
    // },
    // totalAmount:{
    //     type: Number,
    //     trim:true
    // },
    // description:{
    //     type: String,
    //     trim:true
    // },
    // fromDate: {
    //     type: Date,
    // },
    // toDate:{
    //     type:Date
    // },
    // convertedFrom:{
    //     type:Date
    // },
    // convertedTo:{
    //     type:Date
    // },

    // expiryDate:{
    //     type:String
    // },
    
}, {
    timestamps: true
})

let findReducer = function (next) {
    this.populate('orderId',['orderNumber']);
    next();
};
Credit.pre('find', findReducer);

Credit.plugin(mongoosePaginate)
Credit.plugin(mongooseAggregatePaginate);

module.exports  = mongoose.model('user_credits_used', Credit);
